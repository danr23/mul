<!--Видеоролик- Виктор Судаков - Марфа и Мария  -->
<table style="display: inline" border="0" cellpadding="5" cellspacing="5"><tr><td width="364"><strong>Виктор Судаков - Марфа и Мария </strong><p><iframe allowfullscreen="" frameborder="0" scrolling="no" height="290"  width="360" src="https://www.youtube.com/embed/pwk99Fn6xkM"></iframe></p></td></tr></table>




<!--Видеоролик- Михаил Крюков - Великое обещание  -->
<table style="display: inline" border="0" cellpadding="5" cellspacing="5"><tr><td width="364"><strong>Михаил Крюков - Великое обещание </strong><p><iframe allowfullscreen="" frameborder="0" scrolling="no" height="290"  width="360" src="https://www.youtube.com/embed/cizXSq6iOZo"></iframe></p></td></tr></table>




<!--Видеоролик- Виктор Судаков - О простоте  -->
<table style="display: inline" border="0" cellpadding="5" cellspacing="5"><tr><td width="364"><strong>Виктор Судаков - О простоте </strong><p><iframe allowfullscreen="" frameborder="0" scrolling="no" height="290"  width="360" src="https://www.youtube.com/embed/pMc5JbzmHOg"></iframe></p></td></tr></table>




