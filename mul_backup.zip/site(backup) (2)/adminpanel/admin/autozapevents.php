<!--  понедельник -->
<?php 
// имя файла, куда производится запись
$filename = '../datacalendar.json';
// проверка существования файла
if (file_exists($filename)) {
  // если файл существует - открываем его
  $file = fopen($filename, "a");
} else {
  // если файл не существует - создадим его
  $file = fopen($filename, "w");
};
$date = time();
$day = 60 * 60 * 24;
while (date('D', $date) !== 'Mon') $date += $day;
$dat = date('Y-n-j', $date + (28 * $day));

$title = 'Молитва «Внутреннее созерцание в тишине»';
$description = 'Добро пожаловать на молитву «Внутреннее созерцание в тишине»';
$url ='http://newlife.ru/page.php?page=sozercanie';
$h = '08';
$m = '30';

$urlf = filter_var($url, FILTER_VALIDATE_URL);



$space = ' ';
$ret = "\r\n";
$d = '{ "date": "';
$t = '", "title": "';
$des = '", "description": "';
$u = '", "url": "';
$e = '" }';
$z = ',';
$dm = ':';
$pm = ':10';

$alldatetime = $dat.$space.$h.$dm.$m.$pm;
$date = strtotime($alldatetime);
$date = $date*1000;


$fp = fopen ("../datacalendar.json", "r");
     while (!feof($fp))
       {
       $outString=fgets($fp);
       }
    fclose ($fp);
$last=isset($outString[0])?$outString[strlen($outString)-1]:'';
$scobka = '}';

if ($last == $scobka)
{
fwrite($file, $z);
fwrite($file, $ret);
}
else
{
}
fwrite($file, $d);
fwrite($file, $date);
fwrite($file, $t);
fwrite($file, $title);
fwrite($file, $des);
fwrite($file, $description);
fwrite($file, $u);
fwrite($file, $urlf);
fwrite($file, $e);



// закрываем файл
fclose($file);
// направляем пользователя на страницу с формой

?> 

<!--  понедельник событие 2 -->
<?php 
// имя файла, куда производится запись
$filename = '../datacalendar.json';
// проверка существования файла
if (file_exists($filename)) {
  // если файл существует - открываем его
  $file = fopen($filename, "a");
} else {
  // если файл не существует - создадим его
  $file = fopen($filename, "w");
};
$date = time();
$day = 60 * 60 * 24;
while (date('D', $date) !== 'Mon') $date += $day;
$dat = date('Y-n-j', $date + (28 * $day));

$title = 'Альфа - курс';
$description = 'Уникальная возможность обсудить духовные темы во внецерковной обстановке';
$url ='';
$h = '19';
$m = '00';

$urlf = filter_var($url, FILTER_VALIDATE_URL);



$space = ' ';
$ret = "\r\n";
$d = '{ "date": "';
$t = '", "title": "';
$des = '", "description": "';
$u = '", "url": "';
$e = '" }';
$z = ',';
$dm = ':';
$pm = ':10';

$alldatetime = $dat.$space.$h.$dm.$m.$pm;
$date = strtotime($alldatetime);
$date = $date*1000;


$fp = fopen ("../datacalendar.json", "r");
     while (!feof($fp))
       {
       $outString=fgets($fp);
       }
    fclose ($fp);
$last=isset($outString[0])?$outString[strlen($outString)-1]:'';
$scobka = '}';

if ($last == $scobka)
{
fwrite($file, $z);
fwrite($file, $ret);
}
else
{
}
fwrite($file, $d);
fwrite($file, $date);
fwrite($file, $t);
fwrite($file, $title);
fwrite($file, $des);
fwrite($file, $description);
fwrite($file, $u);
fwrite($file, $urlf);
fwrite($file, $e);



// закрываем файл
fclose($file);
// направляем пользователя на страницу с формой

?> 






<!--  вторник -->

<?php 
// имя файла, куда производится запись
$filename = '../datacalendar.json';
// проверка существования файла
if (file_exists($filename)) {
  // если файл существует - открываем его
  $file = fopen($filename, "a");
} else {
  // если файл не существует - создадим его
  $file = fopen($filename, "w");
};
$date = time();
$day = 60 * 60 * 24;
while (date('D', $date) !== 'Tue') $date += $day;
$dat = date('Y-n-j', $date + (28 * $day));

$title = 'Молитва за социальные сферы общества';
$description = 'Добро пожаловать на молитву за социальные сферы общества';
$url ='http://newlife.ru/page.php?page=httpnewliferumolitvavt';
$h = '08';
$m = '30';

$urlf = filter_var($url, FILTER_VALIDATE_URL);



$space = ' ';
$ret = "\r\n";
$d = '{ "date": "';
$t = '", "title": "';
$des = '", "description": "';
$u = '", "url": "';
$e = '" }';
$z = ',';
$dm = ':';
$pm = ':10';

$alldatetime = $dat.$space.$h.$dm.$m.$pm;
$date = strtotime($alldatetime);
$date = $date*1000;


$fp = fopen ("../datacalendar.json", "r");
     while (!feof($fp))
       {
       $outString=fgets($fp);
       }
    fclose ($fp);
$last=isset($outString[0])?$outString[strlen($outString)-1]:'';
$scobka = '}';

if ($last == $scobka)
{
fwrite($file, $z);
fwrite($file, $ret);
}
else
{
}
fwrite($file, $d);
fwrite($file, $date);
fwrite($file, $t);
fwrite($file, $title);
fwrite($file, $des);
fwrite($file, $description);
fwrite($file, $u);
fwrite($file, $urlf);
fwrite($file, $e);



// закрываем файл
fclose($file);
// направляем пользователя на страницу с формой

?> 








<!--  вторник событие 2-->

<?php 
// имя файла, куда производится запись
$filename = '../datacalendar.json';
// проверка существования файла
if (file_exists($filename)) {
  // если файл существует - открываем его
  $file = fopen($filename, "a");
} else {
  // если файл не существует - создадим его
  $file = fopen($filename, "w");
};
$date = time();
$day = 60 * 60 * 24;
while (date('D', $date) !== 'Tue') $date += $day;
$dat = date('Y-n-j', $date + (28 * $day));

$title = 'Домашние группы';
$description = 'Добро пожаловать на домашние группы';
$url ='http://newlife.ru/page.php?page=domgr';
$h = '18';
$m = '30';

$urlf = filter_var($url, FILTER_VALIDATE_URL);



$space = ' ';
$ret = "\r\n";
$d = '{ "date": "';
$t = '", "title": "';
$des = '", "description": "';
$u = '", "url": "';
$e = '" }';
$z = ',';
$dm = ':';
$pm = ':10';

$alldatetime = $dat.$space.$h.$dm.$m.$pm;
$date = strtotime($alldatetime);
$date = $date*1000;


$fp = fopen ("../datacalendar.json", "r");
     while (!feof($fp))
       {
       $outString=fgets($fp);
       }
    fclose ($fp);
$last=isset($outString[0])?$outString[strlen($outString)-1]:'';
$scobka = '}';

if ($last == $scobka)
{
fwrite($file, $z);
fwrite($file, $ret);
}
else
{
}
fwrite($file, $d);
fwrite($file, $date);
fwrite($file, $t);
fwrite($file, $title);
fwrite($file, $des);
fwrite($file, $description);
fwrite($file, $u);
fwrite($file, $urlf);
fwrite($file, $e);



// закрываем файл
fclose($file);
// направляем пользователя на страницу с формой

?> 


<!--  среда -->

<?php 
// имя файла, куда производится запись
$filename = '../datacalendar.json';
// проверка существования файла
if (file_exists($filename)) {
  // если файл существует - открываем его
  $file = fopen($filename, "a");
} else {
  // если файл не существует - создадим его
  $file = fopen($filename, "w");
};
$date = time();
$day = 60 * 60 * 24;
while (date('D', $date) !== 'Wed') $date += $day;
$dat = date('Y-n-j', $date + (28 * $day));

$title = 'Молитва поклонения Словом и ходатайство';
$description = 'Добро пожаловать на молитву поклонения Словом и ходатайство';
$url ='http://newlife.ru/page.php?page=ihop';
$h = '07';
$m = '30';

$urlf = filter_var($url, FILTER_VALIDATE_URL);



$space = ' ';
$ret = "\r\n";
$d = '{ "date": "';
$t = '", "title": "';
$des = '", "description": "';
$u = '", "url": "';
$e = '" }';
$z = ',';
$dm = ':';
$pm = ':10';

$alldatetime = $dat.$space.$h.$dm.$m.$pm;
$date = strtotime($alldatetime);
$date = $date*1000;


$fp = fopen ("../datacalendar.json", "r");
     while (!feof($fp))
       {
       $outString=fgets($fp);
       }
    fclose ($fp);
$last=isset($outString[0])?$outString[strlen($outString)-1]:'';
$scobka = '}';

if ($last == $scobka)
{
fwrite($file, $z);
fwrite($file, $ret);
}
else
{
}
fwrite($file, $d);
fwrite($file, $date);
fwrite($file, $t);
fwrite($file, $title);
fwrite($file, $des);
fwrite($file, $description);
fwrite($file, $u);
fwrite($file, $urlf);
fwrite($file, $e);



// закрываем файл
fclose($file);
// направляем пользователя на страницу с формой

?> 









<!--  среда событие 2-->

<?php 
// имя файла, куда производится запись
$filename = '../datacalendar.json';
// проверка существования файла
if (file_exists($filename)) {
  // если файл существует - открываем его
  $file = fopen($filename, "a");
} else {
  // если файл не существует - создадим его
  $file = fopen($filename, "w");
};
$date = time();
$day = 60 * 60 * 24;
while (date('D', $date) !== 'Wed') $date += $day;
$dat = date('Y-n-j', $date + (28 * $day));

$title = 'Молодежное служение';
$description = 'Добро пожаловать на молодежное служение';
$url ='http://newlife.ru/page.php?page=youth';
$h = '18';
$m = '00';

$urlf = filter_var($url, FILTER_VALIDATE_URL);



$space = ' ';
$ret = "\r\n";
$d = '{ "date": "';
$t = '", "title": "';
$des = '", "description": "';
$u = '", "url": "';
$e = '" }';
$z = ',';
$dm = ':';
$pm = ':10';

$alldatetime = $dat.$space.$h.$dm.$m.$pm;
$date = strtotime($alldatetime);
$date = $date*1000;


$fp = fopen ("../datacalendar.json", "r");
     while (!feof($fp))
       {
       $outString=fgets($fp);
       }
    fclose ($fp);
$last=isset($outString[0])?$outString[strlen($outString)-1]:'';
$scobka = '}';

if ($last == $scobka)
{
fwrite($file, $z);
fwrite($file, $ret);
}
else
{
}
fwrite($file, $d);
fwrite($file, $date);
fwrite($file, $t);
fwrite($file, $title);
fwrite($file, $des);
fwrite($file, $description);
fwrite($file, $u);
fwrite($file, $urlf);
fwrite($file, $e);



// закрываем файл
fclose($file);
// направляем пользователя на страницу с формой

?> 




<!--  среда событие 3-->

<?php 
// имя файла, куда производится запись
$filename = '../datacalendar.json';
// проверка существования файла
if (file_exists($filename)) {
  // если файл существует - открываем его
  $file = fopen($filename, "a");
} else {
  // если файл не существует - создадим его
  $file = fopen($filename, "w");
};
$date = time();
$day = 60 * 60 * 24;
while (date('D', $date) !== 'Wed') $date += $day;
$dat = date('Y-n-j', $date + (28 * $day));

$title = 'Женское служение «Свобода матери»';
$description = 'Добро пожаловать на женское служение «Свобода матери»';
$url ='http://newlife.ru/page.php?page=ghenskoeslughenie';
$h = '19';
$m = '00';

$urlf = filter_var($url, FILTER_VALIDATE_URL);



$space = ' ';
$ret = "\r\n";
$d = '{ "date": "';
$t = '", "title": "';
$des = '", "description": "';
$u = '", "url": "';
$e = '" }';
$z = ',';
$dm = ':';
$pm = ':10';

$alldatetime = $dat.$space.$h.$dm.$m.$pm;
$date = strtotime($alldatetime);
$date = $date*1000;


$fp = fopen ("../datacalendar.json", "r");
     while (!feof($fp))
       {
       $outString=fgets($fp);
       }
    fclose ($fp);
$last=isset($outString[0])?$outString[strlen($outString)-1]:'';
$scobka = '}';

if ($last == $scobka)
{
fwrite($file, $z);
fwrite($file, $ret);
}
else
{
}
fwrite($file, $d);
fwrite($file, $date);
fwrite($file, $t);
fwrite($file, $title);
fwrite($file, $des);
fwrite($file, $description);
fwrite($file, $u);
fwrite($file, $urlf);
fwrite($file, $e);



// закрываем файл
fclose($file);
// направляем пользователя на страницу с формой

?> 



<!--  Четверг -->

<?php 
// имя файла, куда производится запись
$filename = '../datacalendar.json';
// проверка существования файла
if (file_exists($filename)) {
  // если файл существует - открываем его
  $file = fopen($filename, "a");
} else {
  // если файл не существует - создадим его
  $file = fopen($filename, "w");
};
$date = time();
$day = 60 * 60 * 24;
while (date('D', $date) !== 'Thu') $date += $day;
$dat = date('Y-n-j', $date + (28 * $day));

$title = 'Ходатайственная молитва';
$description = 'Добро пожаловать на ходатайственную молитву';
$url ='http://newlife.ru/page.php?page=hodataystvo';
$h = '08';
$m = '30';

$urlf = filter_var($url, FILTER_VALIDATE_URL);



$space = ' ';
$ret = "\r\n";
$d = '{ "date": "';
$t = '", "title": "';
$des = '", "description": "';
$u = '", "url": "';
$e = '" }';
$z = ',';
$dm = ':';
$pm = ':10';

$alldatetime = $dat.$space.$h.$dm.$m.$pm;
$date = strtotime($alldatetime);
$date = $date*1000;


$fp = fopen ("../datacalendar.json", "r");
     while (!feof($fp))
       {
       $outString=fgets($fp);
       }
    fclose ($fp);
$last=isset($outString[0])?$outString[strlen($outString)-1]:'';
$scobka = '}';

if ($last == $scobka)
{
fwrite($file, $z);
fwrite($file, $ret);
}
else
{
}
fwrite($file, $d);
fwrite($file, $date);
fwrite($file, $t);
fwrite($file, $title);
fwrite($file, $des);
fwrite($file, $description);
fwrite($file, $u);
fwrite($file, $urlf);
fwrite($file, $e);



// закрываем файл
fclose($file);
// направляем пользователя на страницу с формой

?> 


<!--  Четверг событие 2 -->

<?php 
// имя файла, куда производится запись
$filename = '../datacalendar.json';
// проверка существования файла
if (file_exists($filename)) {
  // если файл существует - открываем его
  $file = fopen($filename, "a");
} else {
  // если файл не существует - создадим его
  $file = fopen($filename, "w");
};
$date = time();
$day = 60 * 60 * 24;
while (date('D', $date) !== 'Thu') $date += $day;
$dat = date('Y-n-j', $date + (28 * $day));

$title = 'Молитва поклонения Словом и ходатайство';
$description = 'Добро пожаловать на молитву поклонения Словом и ходатайства';
$url ='http://newlife.ru/page.php?page=ihop';
$h = '17';
$m = '30';

$urlf = filter_var($url, FILTER_VALIDATE_URL);



$space = ' ';
$ret = "\r\n";
$d = '{ "date": "';
$t = '", "title": "';
$des = '", "description": "';
$u = '", "url": "';
$e = '" }';
$z = ',';
$dm = ':';
$pm = ':10';

$alldatetime = $dat.$space.$h.$dm.$m.$pm;
$date = strtotime($alldatetime);
$date = $date*1000;


$fp = fopen ("../datacalendar.json", "r");
     while (!feof($fp))
       {
       $outString=fgets($fp);
       }
    fclose ($fp);
$last=isset($outString[0])?$outString[strlen($outString)-1]:'';
$scobka = '}';

if ($last == $scobka)
{
fwrite($file, $z);
fwrite($file, $ret);
}
else
{
}
fwrite($file, $d);
fwrite($file, $date);
fwrite($file, $t);
fwrite($file, $title);
fwrite($file, $des);
fwrite($file, $description);
fwrite($file, $u);
fwrite($file, $urlf);
fwrite($file, $e);



// закрываем файл
fclose($file);
// направляем пользователя на страницу с формой

?> 


<!--  Четверг событие 3 -->
<?php 
// имя файла, куда производится запись
$filename = '../datacalendar.json';
// проверка существования файла
if (file_exists($filename)) {
  // если файл существует - открываем его
  $file = fopen($filename, "a");
} else {
  // если файл не существует - создадим его
  $file = fopen($filename, "w");
};
$date = time();
$day = 60 * 60 * 24;
while (date('D', $date) !== 'Thu') $date += $day;
$dat = date('Y-n-j', $date + (28 * $day));

$title = 'Общецерковное богослужение';
$description = 'Добро пожаловать на общецерковное богослужение';
$url ='http://newlife.ru/page.php?page=obshecerkovnye-slugheniya';
$h = '19';
$m = '00';

$urlf = filter_var($url, FILTER_VALIDATE_URL);



$space = ' ';
$ret = "\r\n";
$d = '{ "date": "';
$t = '", "title": "';
$des = '", "description": "';
$u = '", "url": "';
$e = '" }';
$z = ',';
$dm = ':';
$pm = ':10';

$alldatetime = $dat.$space.$h.$dm.$m.$pm;
$date = strtotime($alldatetime);
$date = $date*1000;


$fp = fopen ("../datacalendar.json", "r");
     while (!feof($fp))
       {
       $outString=fgets($fp);
       }
    fclose ($fp);
$last=isset($outString[0])?$outString[strlen($outString)-1]:'';
$scobka = '}';

if ($last == $scobka)
{
fwrite($file, $z);
fwrite($file, $ret);
}
else
{
}
fwrite($file, $d);
fwrite($file, $date);
fwrite($file, $t);
fwrite($file, $title);
fwrite($file, $des);
fwrite($file, $description);
fwrite($file, $u);
fwrite($file, $urlf);
fwrite($file, $e);



// закрываем файл
fclose($file);
// направляем пользователя на страницу с формой

?> 







<!-- Пятница -->

<?php 
// имя файла, куда производится запись
$filename = '../datacalendar.json';
// проверка существования файла
if (file_exists($filename)) {
  // если файл существует - открываем его
  $file = fopen($filename, "a");
} else {
  // если файл не существует - создадим его
  $file = fopen($filename, "w");
};
$date = time();
$day = 60 * 60 * 24;
while (date('D', $date) !== 'Fri') $date += $day;
$dat = date('Y-n-j', $date + (28 * $day));

$title = 'Молитва «Внутреннее созерцание в тишине»';
$description = 'Добро пожаловать на молитву «Внутреннее созерцание в тишине»';
$url ='http://newlife.ru/page.php?page=sozercanie';
$h = '08';
$m = '30';

$urlf = filter_var($url, FILTER_VALIDATE_URL);



$space = ' ';
$ret = "\r\n";
$d = '{ "date": "';
$t = '", "title": "';
$des = '", "description": "';
$u = '", "url": "';
$e = '" }';
$z = ',';
$dm = ':';
$pm = ':10';

$alldatetime = $dat.$space.$h.$dm.$m.$pm;
$date = strtotime($alldatetime);
$date = $date*1000;


$fp = fopen ("../datacalendar.json", "r");
     while (!feof($fp))
       {
       $outString=fgets($fp);
       }
    fclose ($fp);
$last=isset($outString[0])?$outString[strlen($outString)-1]:'';
$scobka = '}';

if ($last == $scobka)
{
fwrite($file, $z);
fwrite($file, $ret);
}
else
{
}
fwrite($file, $d);
fwrite($file, $date);
fwrite($file, $t);
fwrite($file, $title);
fwrite($file, $des);
fwrite($file, $description);
fwrite($file, $u);
fwrite($file, $urlf);
fwrite($file, $e);



// закрываем файл
fclose($file);
// направляем пользователя на страницу с формой

?> 





<!--  Суббота -->

<?php 
// имя файла, куда производится запись
$filename = '../datacalendar.json';
// проверка существования файла
if (file_exists($filename)) {
  // если файл существует - открываем его
  $file = fopen($filename, "a");
} else {
  // если файл не существует - создадим его
  $file = fopen($filename, "w");
};
$date = time();
$day = 60 * 60 * 24;
while (date('D', $date) !== 'Sat') $date += $day;
$dat = date('Y-n-j', $date + (28 * $day));

$title = 'Молитва поклонения Словом и ходатайство';
$description = 'Добро пожаловать на молитву поклонения Словом и ходатайства';
$url ='http://newlife.ru/page.php?page=ihop';
$h = '10';
$m = '00';

$urlf = filter_var($url, FILTER_VALIDATE_URL);



$space = ' ';
$ret = "\r\n";
$d = '{ "date": "';
$t = '", "title": "';
$des = '", "description": "';
$u = '", "url": "';
$e = '" }';
$z = ',';
$dm = ':';
$pm = ':10';

$alldatetime = $dat.$space.$h.$dm.$m.$pm;
$date = strtotime($alldatetime);
$date = $date*1000;


$fp = fopen ("../datacalendar.json", "r");
     while (!feof($fp))
       {
       $outString=fgets($fp);
       }
    fclose ($fp);
$last=isset($outString[0])?$outString[strlen($outString)-1]:'';
$scobka = '}';

if ($last == $scobka)
{
fwrite($file, $z);
fwrite($file, $ret);
}
else
{
}
fwrite($file, $d);
fwrite($file, $date);
fwrite($file, $t);
fwrite($file, $title);
fwrite($file, $des);
fwrite($file, $description);
fwrite($file, $u);
fwrite($file, $urlf);
fwrite($file, $e);



// закрываем файл
fclose($file);
// направляем пользователя на страницу с формой

?> 




<!--  Воскресенье -->

<?php 
// имя файла, куда производится запись
$filename = '../datacalendar.json';
// проверка существования файла
if (file_exists($filename)) {
  // если файл существует - открываем его
  $file = fopen($filename, "a");
} else {
  // если файл не существует - создадим его
  $file = fopen($filename, "w");
};
$date = time();
$day = 60 * 60 * 24;
while (date('D', $date) !== 'Sun') $date += $day;
$dat = date('Y-n-j', $date + (28 * $day));

$title = 'Воскресное богослужение';
$description = 'Добро пожаловать на воскресное богослужение';
$url ='http://newlife.ru/page.php?page=obshecerkovnye-slugheniya';
$h = '11';
$m = '00';

$urlf = filter_var($url, FILTER_VALIDATE_URL);



$space = ' ';
$ret = "\r\n";
$d = '{ "date": "';
$t = '", "title": "';
$des = '", "description": "';
$u = '", "url": "';
$e = '" }';
$z = ',';
$dm = ':';
$pm = ':10';

$alldatetime = $dat.$space.$h.$dm.$m.$pm;
$date = strtotime($alldatetime);
$date = $date*1000;


$fp = fopen ("../datacalendar.json", "r");
     while (!feof($fp))
       {
       $outString=fgets($fp);
       }
    fclose ($fp);
$last=isset($outString[0])?$outString[strlen($outString)-1]:'';
$scobka = '}';

if ($last == $scobka)
{
fwrite($file, $z);
fwrite($file, $ret);
}
else
{
}
fwrite($file, $d);
fwrite($file, $date);
fwrite($file, $t);
fwrite($file, $title);
fwrite($file, $des);
fwrite($file, $description);
fwrite($file, $u);
fwrite($file, $urlf);
fwrite($file, $e);



// закрываем файл
fclose($file);
// направляем пользователя на страницу с формой

?> 

