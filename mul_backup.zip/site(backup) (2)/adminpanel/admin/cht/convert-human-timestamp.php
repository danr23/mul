<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="ru-ru" lang="ru-ru">
<head><meta http-equiv="content-type" content="text/html; charset=utf-8" />
<title>human -- timestamp</title>
<link rel="stylesheet" type="text/css" href="tcal.css" />
<script type="text/javascript" src="tcal.js"></script> 
<script type="text/javascript">
 //Скрипт очищающий форму от текста при нажатии на нее курсора
function doClear(theText) { if (theText.value == theText.defaultValue) { theText.value = "" } }
function doDefault(theText) { if (theText.value == "") { theText.value = theText.defaultValue } }
</script>
</head>
<body bgcolor="#bbbbbb">

<form method="post" action="" enctype="multipart/form-data" id="f" name="f" method="post" >
<p align="left">
<table class="alltext" border="0"><tr><td>
Дата/время в формате "human":<br><input type="date" size="11" name="date" value="дата" class="tcal" onFocus="doClear(this)"
    onBlur="doDefault(this)"> / <input type="text" size="2" name="h" value="чч" onFocus="doClear(this)"
    onBlur="doDefault(this)"> <input type="text" size="2" name="m" value="мм" onFocus="doClear(this)"
    onBlur="doDefault(this)">

<input type="submit" id="continue" value="Ok">
</td></tr></table>
</p>
<input type="hidden" name="form" value="upfile"><br>
</form>

<?
ini_set('display_errors','Off');
error_reporting('off');
$date = $_POST['date'];
$h = $_POST['h'];
$m = $_POST['m'];
$human = $date." ".$h.":".$m.":10";
if ($date == '') {
$human = date("d.m.y H:i");
} else {
$humants = strtotime($human);
$humants = $humants*1000;
}

if ($humants == '0') {
$humants = 'некорректно введены дата/время';
} else {
}
?>
<table border="1"><tr><td>
Дата время в human - формате</td><td><font color="cc0000"><strong><? echo "$human"; ?></strong></font>
</td></tr><tr><td>
Дата время в формате timestamp (ms)</td><td><font color="cc0000"><strong><? echo "$humants"; ?></strong></font>
</td></tr></table>

</body>
</html>
