<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="ru-ru" lang="ru-ru">
<head><meta http-equiv="content-type" content="text/html; charset=utf-8" />
<title>convert (timestamp human)</title>
</head>
<body width="100%" bgcolor="#bbbbbb" align="center">
<div align="center">
<table border="0" width="1130"><tr><td>
<table width="1100" border="0"><tr><td>
перевести дату из формата human в формат timestamp:</td><td>перевести дату из формата timestamp в формат human:</td></tr><tr><td>
<iframe frameborder="no" scrolling="no" src="convert-human-timestamp.php" width="545" height="450">
</iframe>
</td><td>
<iframe frameborder="no" scrolling="no" src="convert-timestamp-human.php" width="545" height="450">
</iframe>
</td></tr></table>
<p><em>* timestamp - формат даты/времени который записывает их как количество секунд прошедших с 1 января 1970 г. 00:00:00<br>
Календарь использует timestamp в милисекундах (timestamp ms) т.е. количество секунд timestamp умноженное на 1000</em></p>


</td></tr></table>
</div>
</body>
</html>
