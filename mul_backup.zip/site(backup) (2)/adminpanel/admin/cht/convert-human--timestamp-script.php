<?php 

$space = ' ';
$ret = "\r\n";
$pm = ':10';

$alldatetime = $dat.$space.$h.$dm.$m.$pm;
$date = strtotime($alldatetime);
$date = $date*1000;

?> 
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="ru-ru" lang="ru-ru">
<head><meta http-equiv="content-type" content="text/html; charset=utf-8" />
<title>human -- timestamp</title>
</head>
<body>






</body>
</html>
