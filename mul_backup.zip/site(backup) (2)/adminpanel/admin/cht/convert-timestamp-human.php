<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="ru-ru" lang="ru-ru">
<head><meta http-equiv="content-type" content="text/html; charset=utf-8" />
<title>timestamp - human</title>
<script type="text/javascript">
 //Скрипт очищающий форму от текста при нажатии на нее курсора
function doClear(theText) { if (theText.value == theText.defaultValue) { theText.value = "" } }
function doDefault(theText) { if (theText.value == "") { theText.value = theText.defaultValue } }
</script>
</head>
<body bgcolor="#bbbbbb">

<form method="post" action="" enctype="multipart/form-data" id="f" name="f" method="post" >
<p align="left">
<table class="alltext" border="0"><tr><td>
Дата/время в формате "timestamp (ms)":<br><input type="date" size="11" name="timestampms" value="<? $timestamp = time(); $timestampms = $timestamp*1000; echo ($timestampms); ?>" onFocus="doClear(this)"
    onBlur="doDefault(this)">

<input type="submit" id="continue" value="Ok">
</td></tr></table>
</p>
<input type="hidden" name="form" value="upfile"><br>
</form>

<?
ini_set('display_errors','Off');
error_reporting('off');
$timestampms = $_POST['timestampms'];
$timestamp = $timestampms/1000;
$dthuman = date( 'Y-n-j H:i:s', $timestamp );
?>
<table border="1"><tr><td>
Дата время в формате timestamp (ms)</td><td><font color="cc0000"><strong><? echo "$timestampms"; ?></strong></font>
</td></tr><tr><td>
Дата время в human - формате</td><td><font color="cc0000"><strong><? echo "$dthuman"; ?></strong></font>
</td></tr></table>

</body>
</html>
