<?php
$derectory = "../../uploads";
$openderectory=opendir($derectory);
while ($fileindir = readdir($openderectory))
{
if (($fileindir!=".")&&($fileindir!=".."))
        {
                $perem[] = $fileindir;
        }
}
closedir($openderectory);
if (sizeof($perem)!=0)
{
rsort($perem);
$all=sizeof($perem);

}
else
{
        echo ("NO");
        die;
}







?>




<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="ru-ru" lang="ru-ru">
<head><meta http-equiv="content-type" content="text/html; charset=utf-8" />
<title>newlife.ru - редактировать</title>
<style>
textarea {
resize:none
}
</style>
<style>
   select {
    width: 590px;
   }
   option {
    width: 565px;
   }
  </style>
</head>
<body>
<table bgcolor="#e5f1f0" align="center" border="0" width="900" cellpadding="10" cellspacing="10"><tr><td>
<img src="../imgo.png" border="0" align="left" hspace="6" vspace="6"><br><br>
<h3 align="center"><font color="#cc0000">Редактор страниц сайта</font></h3>
<BR><BR>
<strong>Пожалуйста выберите страницу сайта для редактирования:</strong><br><br>
<form action="up/" method="get">
<?php
    echo 'Выбрать страницу <select name="razdel">';
    foreach($perem as $item){
    echo "<option value=$item>".$item.'</option>';
    }
    echo '</select>';

?>


   <p><input type="submit" value="Редактировать"></p>
  </form>
<br><br><br><br>

<p align="right"><a href="index.php"><font color="#005c54"><em>Назад, в меню</em></font></a></p>
</td></tr></table>

</body>
</html>
