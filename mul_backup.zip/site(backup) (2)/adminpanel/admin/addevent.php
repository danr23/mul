<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="ru-ru" lang="ru-ru">
<head><meta http-equiv="content-type" content="text/html; charset=utf-8" />
<title>Добавить мероприятие</title>
<link rel="stylesheet" type="text/css" href="tcal.css" />
<script type="text/javascript" src="tcal.js"></script> 
</head>

<script type="text/javascript">
 //Скрипт очищающий форму от текста при нажатии на нее курсора
function doClear(theText) { if (theText.value == theText.defaultValue) { theText.value = "" } }
function doDefault(theText) { if (theText.value == "") { theText.value = theText.defaultValue } }
</script>

<body>
<table bgcolor="#e5f1f0" align="center" border="0" width="900" cellpadding="10" cellspacing="10"><tr><td>
<img src="../imgo.png" border="0" align="left" hspace="6" vspace="6">
<BR><BR>
<h3 align="center"><font color="#cc0000">Добавить мероприятие</font></h3><BR><BR>


<form action="scriptcalendar.php" method="post">
<p align="center">

<input type="date" size="11" name="date" value="дата" class="tcal" onFocus="doClear(this)"
    onBlur="doDefault(this)"> <input type="text" size="2" name="h" value="чч" onFocus="doClear(this)"
    onBlur="doDefault(this)"> <input type="text" size="2" name="m" value="мм" onFocus="doClear(this)"
    onBlur="doDefault(this)">
<br><br>
<input type="text" size="50" name="title" value="Название мероприятия" onFocus="doClear(this)"
    onBlur="doDefault(this)">
<br><br>
<input type="text" size="50" name="description" value="Описание мероприятия" onFocus="doClear(this)"
    onBlur="doDefault(this)">
<br><br>
<input type="text" size="50" name="url" value="Ссылка на подробное описание мероприятия" onFocus="doClear(this)"
    onBlur="doDefault(this)">
<br><br>
<input type="submit" value="Загрузить">
</p>

</form>
<br><br>
<p align="right"><a href="index.php"><font color="#005c54"><em>Назад, в меню</em></font></a></p>
</td></tr></table>
</body>
</html> 

