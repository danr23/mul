<?php 
// имя файла, куда производится запись
$filename = '../datacalendar.json';
// проверка существования файла
if (file_exists($filename)) {
  // если файл существует - открываем его
  $file = fopen($filename, "a");
} else {
  // если файл не существует - создадим его
  $file = fopen($filename, "w");
};
$date = $_POST['date'];
$title = $_POST['title'];
$description = $_POST['description'];
$url = $_POST['url'];
$h = $_POST['h'];
$m = $_POST['m'];

$urlf = filter_var($url, FILTER_VALIDATE_URL);




$space = ' ';
$ret = "\r\n";
$d = '{ "date": "';
$t = '", "title": "';
$des = '", "description": "';
$u = '", "url": "';
$e = '" }';
$z = ',';
$dm = ':';
$pm = ':10';

$alldatetime = $date.$space.$h.$dm.$m.$pm;
$date = strtotime($alldatetime);
$date = $date*1000;


$fp = fopen ("../datacalendar.json", "r");
     while (!feof($fp))
       {
       $outString=fgets($fp);
       }
    fclose ($fp);
$last=isset($outString[0])?$outString[strlen($outString)-1]:'';
$scobka = '}';

if ($last == $scobka)
{
fwrite($file, $z);
fwrite($file, $ret);
}
else
{
}
fwrite($file, $d);
fwrite($file, $date);
fwrite($file, $t);
fwrite($file, $title);
fwrite($file, $des);
fwrite($file, $description);
fwrite($file, $u);
fwrite($file, $urlf);
fwrite($file, $e);



// закрываем файл
fclose($file);
// направляем пользователя на страницу с формой
header("Location: OKcalendar.php");
?> 
