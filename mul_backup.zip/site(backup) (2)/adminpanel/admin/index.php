<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="ru-ru" lang="ru-ru">
<head><meta http-equiv="content-type" content="text/html; charset=utf-8" />
<title>Панель администратора</title>
</head>
<body>
<table bgcolor="#e5f1f0" align="center" border="0" width="900" cellpadding="10" cellspacing="10"><tr><td>
<img src="../imgo.png" border="0" align="left" hspace="6" vspace="6">
<p align="right"></p><h2 align="left"><font color="#000000">Панель администратора</font></h2><p align="right">
</p><BR><hr width="600"><br>

<p align="center"><a href="addpage.php"><font color="#005c54">Добавить новые разделы</font></a></p>
<p align="center"><a href="editpage.php"><font color="#005c54">Добавить видеоролики в уже существующие разделы</font></a></p>
<p align="center"><a href="upimg"><font color="#005c54">Загрузить файлы</font></a></p>
<br><hr width="600"><br>
</body>
</html>
