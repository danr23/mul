<?
header('WWW-Authenticate: Basic realm="Authentication"'); header('HTTP/1.1 401 Unauthorized');

echo '<script type="text/javascript">'; 
echo 'window.location.href="http://newlife.ru/";'; 
echo '</script>'; 
?>
