<?php 
// имя файла, куда производится запись
$filename = '../Datavideo.php';
// проверка существования файла
if (file_exists($filename)) {
  // если файл существует - открываем его
  $file = fopen($filename, "a");
} else {
  // если файл не существует - создадим его
  $file = fopen($filename, "w");
};
$header = $_POST['header'];
$link = $_POST['link'];

$linkf = filter_var($link, FILTER_VALIDATE_URL);

$space = ' ';
$ret = "\r\n";
$l = '<p><iframe allowfullscreen="" frameborder="0" scrolling="no" height="298"  width="480" src="';
$le = '"></iframe></p>';
$h = '<strong>';
$he = '</strong>';
$t ='<table border="0" cellpadding="10" cellspacing="10"><tr><td width="484">';
$te = '</td></tr></table><br>';
$tetd = '<td width="484">';
$td = '</td>';
$tdd = '</td>';

    $lines = file('Data.php');  // теперь в $lines массив строк файла
    $ps = ($lines[count($lines)-1]); // выводим последнюю строку

$rest = substr("$ps", "-5");// returns "f"

if ($rest == $td)
{
fwrite($file, $ret);
fwrite($file, $ret);
fwrite($file, $tetd);
fwrite($file, $h);
fwrite($file, $header);
fwrite($file, $he);
fwrite($file, $l);
fwrite($file, $linkf);
fwrite($file, $le);
fwrite($file, $te);
fwrite($file, $ret);
fwrite($file, $ret);
fwrite($file, $ret);
}
else
{
fwrite($file, $ret);
fwrite($file, $ret);
fwrite($file, $ret);
fwrite($file, $t);
fwrite($file, $h);
fwrite($file, $header);
fwrite($file, $he);
fwrite($file, $l);
fwrite($file, $linkf);
fwrite($file, $le);
fwrite($file, $tdd);
}



// закрываем файл
fclose($file);
// направляем пользователя на страницу с формой
header("Location: OK.php");
?> 
