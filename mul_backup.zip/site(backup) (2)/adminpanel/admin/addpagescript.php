<?php 
$page = $_POST['page'];
$page = preg_replace("|&[a-z]+;|is", "", $page);
$page = preg_replace("|<[^>]+>|is", "", $page);

$translit = array(
   
            'а' => 'a',   'б' => 'b',   'в' => 'v',
  
            'г' => 'g',   'д' => 'd',   'е' => 'e',
  
            'ё' => 'yo',   'ж' => 'zh',  'з' => 'z',
  
            'и' => 'i',   'й' => 'j',   'к' => 'k',
  
            'л' => 'l',   'м' => 'm',   'н' => 'n',
  
            'о' => 'o',   'п' => 'p',   'р' => 'r',
  
            'с' => 's',   'т' => 't',   'у' => 'u',
  
            'ф' => 'f',   'х' => 'x',   'ц' => 'c',
  
            'ч' => 'ch',  'ш' => 'sh',  'щ' => 'shh',
  
            'ь' => '',  'ы' => 'y',   'ъ' => '',
  
            'э' => 'e',   'ю' => 'yu',  'я' => 'ya',
          
  
            'А' => 'A',   'Б' => 'B',   'В' => 'V',
  
            'Г' => 'G',   'Д' => 'D',   'Е' => 'E',
  
            'Ё' => 'YO',   'Ж' => 'Zh',  'З' => 'Z',
  
            'И' => 'I',   'Й' => 'J',   'К' => 'K',
  
            'Л' => 'L',   'М' => 'M',   'Н' => 'N',
  
            'О' => 'O',   'П' => 'P',   'Р' => 'R',
  
            'С' => 'S',   'Т' => 'T',   'У' => 'U',
  
            'Ф' => 'F',   'Х' => 'X',   'Ц' => 'C',
  
            'Ч' => 'CH',  'Ш' => 'SH',  'Щ' => 'SHH',
  
            'Ь' => '',  'Ы' => 'Y',   'Ъ' => '',
  
            'Э' => 'E',   'Ю' => 'YU',  'Я' => 'YA',
  
        ); 
 $page = strtr($page, $translit);
$page = preg_replace("|[^-a-z0-9а-яё]+|is", "", $page);








// имя файла, куда производится запись
$filenamea = '../../answers-menu-base.htm';
// проверка существования файла
if (file_exists($filenamea)) {
  // если файл существует - открываем его
  $file = fopen($filenamea, "a");
} else {
  // если файл не существует - создадим его
  $file = fopen($filenamea, "w");
};

$link = $_POST['link'];

$linkf = filter_var($link, FILTER_VALIDATE_URL);

$space = ' ';
$ret = "\r\n";
$a = '<a href="';
$aend = '">';
$img = '<img hspace="10" vspace="10" align="left" border="0" width="480" height="300" src="';
$imgend = '">';
$aclose = '</a> ';
$pageanswers = "files.php?razdel=$page";


fwrite($file, $ret);
fwrite($file, $a);
fwrite($file, $pageanswers);
fwrite($file, $aend);
fwrite($file, $img);
fwrite($file, $link);
fwrite($file, $imgend);
fwrite($file, $aclose);
fwrite($file, $ret);

fclose($file);





mkdir ("../../uploads/$page", 0777);

header("Location: up/?razdel=$page");
?>
