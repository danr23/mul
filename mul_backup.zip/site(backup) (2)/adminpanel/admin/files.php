<?
include "../../top.php";
include "../../menu.php";
?>
<table align="center" border="0" width="1100" height="500"><tr><td align="center" valign="top">
<?php
$razdel = $_GET['razdel'];
$derectory = "../../uploads/$razdel";
$openderectory=opendir($derectory);
while ($fileindir = readdir($openderectory))
{
if (($fileindir!=".")&&($fileindir!=".."))
        {
                $perem[] = $fileindir;
        }
}
closedir($openderectory);
if (sizeof($perem)!=0)
{
rsort($perem);
$all=sizeof($perem);

}
else
{
        echo ("NO");
        die;
}
    
    foreach($perem as $item){
    echo '<table style="display: inline" border="0" cellpadding="5" cellspacing="5"><tr><td width="340"> <video width="320" height="240" controls>
<source src="../../uploads/';
    echo ($item) ;
    echo '" type="video/ogg; ">
</video></td></tr></table>';
//    echo ($item) ;
//    echo '</a>';
//    echo '<br>';
    }

?>
</td></tr></table>
<?
include "../../bottom.php"
?>
