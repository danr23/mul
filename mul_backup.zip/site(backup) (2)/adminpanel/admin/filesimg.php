<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="ru-ru" lang="ru-ru">
<head><meta http-equiv="content-type" content="text/html; charset=utf-8" />
<title>Панель администратора сайта</title>
</head>
<body>
<table border="0" width="500" height="500"><tr><td valign="top">
<?php
$derectory = "uploadsimg";
$openderectory=opendir($derectory);
while ($fileindir = readdir($openderectory))
{
if (($fileindir!=".")&&($fileindir!=".."))
        {
                $perem[] = $fileindir;
        }
}
closedir($openderectory);
if (sizeof($perem)!=0)
{
rsort($perem);
$all=sizeof($perem);

}
else
{
        echo ("NO");
        die;
}
    
    foreach($perem as $item){
    echo '
    <br><a style="background-color:#ddeeee;border:#ccdddd 1px solid;border-radius:25px;box-shadow: 0 0 0 2px #bbcccc, 0 0 0 4px #ddeeee;color:#121212;" href="uploadsimg/';
    echo ($item) ;
    echo '" target="_blank">';
    echo ($item) ;
    echo '</a>';
    echo '<br>';
    }

?>
</td></tr></table>
</body></html>
