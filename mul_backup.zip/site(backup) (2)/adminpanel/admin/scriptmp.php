<?php 
// имя файла, куда производится запись
$filename = '../Datamp.php';
// проверка существования файла
if (file_exists($filename)) {
  // если файл существует - открываем его
  $file = fopen($filename, "a");
} else {
  // если файл не существует - создадим его
  $file = fopen($filename, "w");
};

file_put_contents('../Datamp.php', '');


$header1 = $_POST['header1'];
$link1 = $_POST['link1'];
$header2 = $_POST['header2'];
$link2 = $_POST['link2'];
$header3 = $_POST['header3'];
$link3 = $_POST['link3'];


$link1f = filter_var($link1, FILTER_VALIDATE_URL);

$link2f = filter_var($link2, FILTER_VALIDATE_URL);

$link3f = filter_var($link3, FILTER_VALIDATE_URL);



$space = ' ';
$ret = "\r\n";
$l = '<p><iframe allowfullscreen="" frameborder="0" scrolling="no" height="290"  width="360" src="';
$le = '"></iframe></p>';
$h = '<strong>';
$he = '</strong>';
$t ='<table style="display: inline" border="0" cellpadding="5" cellspacing="5"><tr><td width="364">';
$te = '</td></tr></table>';
$comment1 = "<!--Видеоролик- $header1 -->";
$comment2 = "<!--Видеоролик- $header2 -->";
$comment3 = "<!--Видеоролик- $header3 -->";

fwrite($file, $comment1);
fwrite($file, $ret);
fwrite($file, $t);
fwrite($file, $h);
fwrite($file, $header1);
fwrite($file, $he);
fwrite($file, $l);
fwrite($file, $link1f);
fwrite($file, $le);
fwrite($file, $te);
fwrite($file, $ret);
fwrite($file, $ret);
fwrite($file, $ret);
fwrite($file, $ret);
fwrite($file, $ret);

fwrite($file, $comment2);
fwrite($file, $ret);
fwrite($file, $t);
fwrite($file, $h);
fwrite($file, $header2);
fwrite($file, $he);
fwrite($file, $l);
fwrite($file, $link2f);
fwrite($file, $le);
fwrite($file, $te);
fwrite($file, $ret);
fwrite($file, $ret);
fwrite($file, $ret);
fwrite($file, $ret);
fwrite($file, $ret);

fwrite($file, $comment3);
fwrite($file, $ret);
fwrite($file, $t);
fwrite($file, $h);
fwrite($file, $header3);
fwrite($file, $he);
fwrite($file, $l);
fwrite($file, $link3f);
fwrite($file, $le);
fwrite($file, $te);
fwrite($file, $ret);
fwrite($file, $ret);
fwrite($file, $ret);
fwrite($file, $ret);
fwrite($file, $ret);

// закрываем файл
fclose($file);
// направляем пользователя на страницу с формой
header("Location: OKmp.php");
?> 
