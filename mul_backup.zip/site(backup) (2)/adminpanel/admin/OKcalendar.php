<html><head><meta http-equiv="content-type" content="text/html; charset=utf-8" /><meta http-equiv="Refresh" content="2;URL= addevent.php" /><title>Мероприятие добавлено, пожалуйста подождите...</title></head><body><p align="center">Мероприятие добавлено.<br>
Пожалуйста подождите 2 секунды...</p></body></html>
