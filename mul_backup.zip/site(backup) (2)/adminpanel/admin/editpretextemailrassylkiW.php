<?
if ($_POST) {
$rezultat = stripslashes($_POST['text']);
  file_put_contents("../../emailrassylkaevents/include.htm",$rezultat);
echo '<html><head><meta http-equiv="content-type" content="text/html; charset=utf-8" /><meta http-equiv="Refresh" content="5;URL= editpretextemailrassylkiW.php" /><title>Сохранено, пожалуйста подождите...</title></head><body><p align="center">Сохранено.<br>Пожалуйста подождите 5 секунд...</p></body></html>';
  exit;
}
$text = htmlspecialchars(file_get_contents("../../emailrassylkaevents/include.htm"));
?>
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="ru-ru" lang="ru-ru">
<head><meta http-equiv="content-type" content="text/html; charset=utf-8" />

<script src="../../js/tinymce/tinymce.js"></script>
  <script type="text/javascript">
  tinymce.init({
    mode: 'exact',
    selector: 'Textarea',
    theme: 'modern',
    width: 780,
    language : "ru",
    height: 440,
    plugins: [
      'advlist autolink link image lists charmap print preview hr anchor pagebreak spellchecker',
      'searchreplace wordcount visualblocks visualchars code fullscreen insertdatetime media nonbreaking',
      'save table contextmenu directionality emoticons template paste textcolor'
    ],
    content_css: 'css/content.css', relative_urls: false, cleanup: false, extended_valid_elements : '?php', allow_conditional_comments: true, allow_html_in_named_anchor: false, verify_html: false,  protect: [
    /\<\/?(if|endif)\>/g,  // Protect <if> & </endif>
    /\<xsl\:[^>]+\>/g,  // Protect <xsl:...>
    /<\?php.*?\?>/g  // Protect php code
  ], remove_script_host: false,
    toolbar: 'insertfile undo redo | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image | print preview media fullpage | forecolor backcolor emoticons'
  });
  </script>

<title>Редактор приветствия (для email - рассылки)</title>
<style>
textarea {
resize:none
}
</style>
</head>
<body>
<table bgcolor="#e5f1f0" align="center" border="0" width="900" cellpadding="10" cellspacing="10"><tr><td>
<img src="../imgo.png" border="0" align="left" hspace="6" vspace="6"><br><br><h3 align="center"><font color="#cc0000">Редактор приветствия (для email - рассылки)</font></h3><br><br>

<form method="POST">
<p align="center">
<textarea name="text" cols="105"
rows="20"><?=$text?></textarea><br><br>
<input type="submit" value="Сохранить">
</p>
</form>
<br><div align="left">
<h4>Файлы:</h4>
<iframe frameborder="no" scrolling="auto" src="../../adminpanel/admin/files.php" width="700" height="300">
</iframe>
<br>
<br>
<p align="right"><a href="index.php"><font color="#005c54"><em>Назад, в меню</em></font></a></p>
</td></tr></table>
</body>
</html>
