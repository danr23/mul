<?php 
$page = $_GET['page'];
// имя файла, куда производится запись
$filename = "../../pages-answers/$page";
// проверка существования файла
if (file_exists($filename)) {
  // если файл существует - открываем его
  $file = fopen($filename, "a");
} else {
  // если файл не существует - создадим его
  $file = fopen($filename, "w");
};

file_put_contents($filename, '');


$header1 = $_POST['header1'];
$link1 = $_POST['link1'];
$header2 = $_POST['header2'];
$link2 = $_POST['link2'];
$header3 = $_POST['header3'];
$link3 = $_POST['link3'];
$header4 = $_POST['header4'];
$link4 = $_POST['link4'];
$header5 = $_POST['header5'];
$link5 = $_POST['link5'];
$header6 = $_POST['header6'];
$link6 = $_POST['link6'];
$header7 = $_POST['header7'];
$link7 = $_POST['link7'];
$header8 = $_POST['header8'];
$link8 = $_POST['link8'];
$header9 = $_POST['header9'];
$link9 = $_POST['link9'];

$link1f = filter_var($link1, FILTER_VALIDATE_URL);

$link2f = filter_var($link2, FILTER_VALIDATE_URL);

$link3f = filter_var($link3, FILTER_VALIDATE_URL);

$link1f = filter_var($link4, FILTER_VALIDATE_URL);

$link2f = filter_var($link5, FILTER_VALIDATE_URL);

$link3f = filter_var($link6, FILTER_VALIDATE_URL);

$link1f = filter_var($link7, FILTER_VALIDATE_URL);

$link2f = filter_var($link8, FILTER_VALIDATE_URL);

$link3f = filter_var($link9, FILTER_VALIDATE_URL);



$space = ' ';
$ret = "\r\n";
$l = '<iframe class="answers" allowfullscreen="" frameborder="0" scrolling="no"  width="78%" src="';
$le = '"></iframe>';
$h = '';
$he = '<br>';
$table ='<table align="center" border="0" cellpadding="5" cellspacing="5">';
$tr = '<tr>';
$td = '<td width="33%">';
$tde = '</td>';
$tre = '</tr>';
$tablee = '</table>';


fwrite($file, $table);
fwrite($file, $tr);
fwrite($file, $td);
fwrite($file, $h);
fwrite($file, $header1);
fwrite($file, $he);
fwrite($file, $l);
fwrite($file, $link1);
fwrite($file, $le);
fwrite($file, $tde);
fwrite($file, $space);
fwrite($file, $ret);



fwrite($file, $td);
fwrite($file, $h);
fwrite($file, $header2);
fwrite($file, $he);
fwrite($file, $l);
fwrite($file, $link2);
fwrite($file, $le);
fwrite($file, $tde);
fwrite($file, $space);
fwrite($file, $ret);


fwrite($file, $td);
fwrite($file, $h);
fwrite($file, $header3);
fwrite($file, $he);
fwrite($file, $l);
fwrite($file, $link3);
fwrite($file, $le);
fwrite($file, $tde);
fwrite($file, $tre);
fwrite($file, $space);
fwrite($file, $ret);

fwrite($file, $tr);
fwrite($file, $td);
fwrite($file, $h);
fwrite($file, $header4);
fwrite($file, $he);
fwrite($file, $l);
fwrite($file, $link4);
fwrite($file, $le);
fwrite($file, $tde);
fwrite($file, $space);
fwrite($file, $ret);

fwrite($file, $td);
fwrite($file, $h);
fwrite($file, $header5);
fwrite($file, $he);
fwrite($file, $l);
fwrite($file, $link5);
fwrite($file, $le);
fwrite($file, $tde);
fwrite($file, $space);
fwrite($file, $ret);

fwrite($file, $td);
fwrite($file, $h);
fwrite($file, $header6);
fwrite($file, $he);
fwrite($file, $l);
fwrite($file, $link6);
fwrite($file, $le);
fwrite($file, $tde);
fwrite($file, $tre);
fwrite($file, $space);
fwrite($file, $ret);

fwrite($file, $tr);
fwrite($file, $td);
fwrite($file, $h);
fwrite($file, $header7);
fwrite($file, $he);
fwrite($file, $l);
fwrite($file, $link7);
fwrite($file, $le);
fwrite($file, $tde);
fwrite($file, $space);
fwrite($file, $ret);

fwrite($file, $td);
fwrite($file, $h);
fwrite($file, $header8);
fwrite($file, $he);
fwrite($file, $l);
fwrite($file, $link8);
fwrite($file, $le);
fwrite($file, $tde);
fwrite($file, $space);
fwrite($file, $ret);

fwrite($file, $td);
fwrite($file, $h);
fwrite($file, $header9);
fwrite($file, $he);
fwrite($file, $l);
fwrite($file, $link9);
fwrite($file, $le);
fwrite($file, $tde);
fwrite($file, $tre);
fwrite($file, $tablee);
fwrite($file, $space);
fwrite($file, $ret);

// закрываем файл
fclose($file);
// направляем пользователя на страницу с формой
header("Location: index.php");
?> 
