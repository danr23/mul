<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="ru-ru" lang="ru-ru">
<head><meta http-equiv="content-type" content="text/html; charset=utf-8" />
<title>newlife.ru - создать новую страницу</title>
<link rel="stylesheet" type="text/css" href="tcal.css" />
<script type="text/javascript" src="tcal.js"></script>
<script type="text/javascript">
 //Скрипт очищающий форму от текста при нажатии на нее курсора
function doClear(theText) { if (theText.value == theText.defaultValue) { theText.value = "" } }
function doDefault(theText) { if (theText.value == "") { theText.value = theText.defaultValue } }
</script> 

</head>



<body>
<table bgcolor="#e5f1f0" align="center" border="0" width="900" cellpadding="10" cellspacing="10"><tr><td>
<img src="../imgo.png" border="0" align="left" hspace="6" vspace="6"><br><br>
<h3 align="center"><font color="#cc0000">Создать новую страницу</font></h3>
<BR><BR>
<table border="0" width="790" cellpadding="10" cellspacing="10" class="alltext" ><tr><td>



<form action="addpagescript.php" method="post" >
<p align="left">
<table class="alltext" border="0"><tr><td>
Название страницы: <input type="text" name="page" size="25"> 
<br>
 <br>
Ссылка на изображение: <input type="text" name="link" size="25"> <br>
<br>
<br><div align="left">
<h4>Файлы:</h4>
<iframe frameborder="no" scrolling="auto" src="../../adminpanel/admin/filesimg.php" width="700" height="300">
</iframe>
<br>
<br>
<input type="submit" id="continue" value="создать">
</td></tr></table>
</p>
</form>

<script type="text/javascript" src="jquery.min.js"></script>
<script type="text/javascript">
$(document).ready(function(){

  $('#continue').prop('disabled', true);

  $('#agree').change(function() {

      $('#continue').prop('disabled', function(i, val) {
        return !val;
      })
  });
})
</script> 



</td></tr></table>
<br><br><br><br>
<p align="right"><a href="index.php"><font color="#005c54"><em>Назад, в меню</em></font></a></p>
</td></tr></table>

</body>
</html>
