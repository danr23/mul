<?
if ($_POST) {
$rezultat = stripslashes($_POST['text']);
  file_put_contents("../../answers-menu-base.htm",$rezultat);
echo '<html><head><meta http-equiv="content-type" content="text/html; charset=utf-8" /><meta http-equiv="Refresh" content="5;URL= editanswersmenu.php" /><title>Сохранено, пожалуйста подождите...</title></head><body><p align="center">Сохранено.<br>Пожалуйста подождите 5 секунд...</p></body></html>';
  exit;
}
$text = htmlspecialchars(file_get_contents("../../answers-menu-base.htm"));
?>
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="ru-ru" lang="ru-ru">
<head><meta http-equiv="content-type" content="text/html; charset=utf-8" />
<title>Редактор страницы меню "ВОПРОС-ОТВЕТ"</title>
<style>
textarea {
resize:none
}
</style>
</head>
<body>
<table bgcolor="#e5f1f0" align="center" border="0" width="900" cellpadding="10" cellspacing="10"><tr><td>
<img src="../imgo.png" border="0" align="left" hspace="6" vspace="6"><br><br><h3 align="center"><font color="#cc0000">Редактор страницы меню "ВОПРОС-ОТВЕТ"</font></h3><br><br>

<form method="POST">
<p align="center">
<textarea name="text" cols="105"
rows="20"><?=$text?></textarea><br><br>
<input type="submit" value="Сохранить">
</p>
</form>
<br>

<p align="right"><a href="index.php"><font color="#005c54"><em>Назад, в меню</em></font></a></p>
</td></tr></table>
</body>
</html>
