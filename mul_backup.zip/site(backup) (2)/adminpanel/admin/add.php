<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="ru-ru" lang="ru-ru">
<head><meta http-equiv="content-type" content="text/html; charset=utf-8" />
<title>Загрузка ссылок на видеоролики для сайта NEWLIFE.RU (раздел "Видео")</title>
</head>

<script type="text/javascript">
 //Скрипт очищающий форму от текста при нажатии на нее курсора
function doClear(theText) { if (theText.value == theText.defaultValue) { theText.value = "" } }
function doDefault(theText) { if (theText.value == "") { theText.value = theText.defaultValue } }
</script>

<body>
<table bgcolor="#e5f1f0" align="center" border="0" width="900" cellpadding="10" cellspacing="10"><tr><td>
<img src="../imgo.png" border="0" align="left" hspace="6" vspace="6">
<BR><BR>
<h3 align="center"><font color="#cc0000">Загрузка ссылок на видеоролики для сайта NEWLIFE.RU (раздел "Видео")</font></h3><BR><BR>


<form action="script.php" method="post">
<p align="center">

<input type="text" size="50" name="header" value="Название проповеди" onFocus="doClear(this)"
    onBlur="doDefault(this)">
<br><br>
<input type="text" size="50" name="link" value="ссылка на проповедь" onFocus="doClear(this)"
    onBlur="doDefault(this)">
<br><br>
<input type="submit" value="Загрузить">
</p>

</form>
<br><br>
<p align="right"><a href="index.php"><font color="#005c54"><em>Назад, в меню</em></font></a></p>
</td></tr></table>
</body>
</html> 

