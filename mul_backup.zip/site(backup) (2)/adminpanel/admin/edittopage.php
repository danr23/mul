<?php
$page = $_GET['page'];
$p = "../../pages/";
$topage = $p.$page;
if ($_POST) {
$rezultat = stripslashes($_POST['text']);
  file_put_contents("$topage",$rezultat);
echo '<html><head><meta http-equiv="content-type" content="text/html; charset=utf-8" /><meta http-equiv="Refresh" content="5;URL= editpage.php" /><title>Сохранено, пожалуйста подождите...</title></head><body><p align="center">Сохранено.<br>Пожалуйста подождите 5 секунд...</p></body></html>';
  exit;
}
$text = htmlspecialchars(file_get_contents("$topage"));
?> 
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="ru-ru" lang="ru-ru">
<head><meta http-equiv="content-type" content="text/html; charset=utf-8" />
<title>Редактировать страницу <? echo "$page"; ?></title>
</head>
<body>
<br>
<table bgcolor="#e5f1f0" align="center" border="0" width="900" cellpadding="10" cellspacing="10"><tr><td>
<img src="../imgo.png" border="0" align="left" hspace="6" vspace="6"><br><br><h3 align="center"><font color="#cc0000">Редактировать страницу <? echo "$page"; ?></font></h3><br><br>

<form method="POST">
<p align="center">
<textarea name="text" cols="105"
rows="20"><?=$text?></textarea><br><br>
<input type="submit" value="Сохранить">
</p>
</form>
<br><div align="left">
<h4>Файлы:</h4>
<iframe frameborder="no" scrolling="auto" src="../../adminpanel/admin/files.php" width="700" height="300">
</iframe>
<br><br>
<!-- <?php
$derectory = "../../uploads";
$openderectory=opendir($derectory);
while ($fileindir = readdir($openderectory))
{
if (($fileindir!=".")&&($fileindir!=".."))
        {
                $perem[] = $fileindir;
        }
}
closedir($openderectory);
if (sizeof($perem)!=0)
{
rsort($perem);
$all=sizeof($perem);

}
else
{
        echo ("NO");
        die;
}
    
    foreach($perem as $item){
    echo '<br><a href="../../uploads/';
    echo ($item) ;
    echo '" target="_blank">';
    echo ($item) ;
    echo '</a>';
    echo '<br>';
    }

?> -->
<!-- <iframe frameborder="no" scrolling="auto" src="../../uploads" width="700" height="450">
</iframe> -->
<br><br>
<p><a href="up"><font color="#005c54">Загрузить файлы</font></a></p><br><br>
</div>
<br><br><br>
ссылка на эту страницу: <font color="#cc0000">http://newlife.ru/page.php?page=<? echo "$page"; ?></font><br>
<p align="right"><a href="index.php"><font color="#005c54"><em>Назад, в меню</em></font></a></p>
</td></tr></table>

</body>
</html>
