<html><head><meta http-equiv="content-type" content="text/html; charset=utf-8" /><meta http-equiv="Refresh" content="3;URL= index.php" /><title>Сохранено, пожалуйста подождите...</title></head><body><p align="center">Сохранено.<br>
Пожалуйста подождите 3 секунды...</p></body></html>
