<html xml:lang="ru-ru" lang="ru-ru">
<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
</head>
<body>
<div align="center">
<table border="0" align="center" width="1092" border="0" cellpadding="10" cellspacing="10"><tr><td>
<?php
include 'adminpanel/DataRI.php';
?>


</td></tr></table>
</div>
</body>
</html>
