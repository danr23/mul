<table style="display: inline" border="0"><tr><td width="28"></td></tr></table><table style="display: inline" border="0" cellpadding="10" cellspacing="10"><tr><td width="484"><strong>Всего лишь слово, ч.1</strong><p><iframe allowfullscreen="" frameborder="0" scrolling="no" height="298"  width="480" src="https://www.youtube.com/embed/IF1Mv_cQQaE"></iframe></p></td></tr></table><table style="display: inline" border="0"><tr><td width="28"></td></tr></table>




<table style="display: inline" border="0"><tr><td width="28"></td></tr></table><table style="display: inline" border="0" cellpadding="10" cellspacing="10"><tr><td width="484"><strong>Всего лишь слово, ч.2</strong><p><iframe allowfullscreen="" frameborder="0" scrolling="no" height="298"  width="480" src="https://www.youtube.com/embed/r_lq-brTFfA"></iframe></p></td></tr></table><table style="display: inline" border="0"><tr><td width="28"></td></tr></table>




<table style="display: inline" border="0"><tr><td width="28"></td></tr></table><table style="display: inline" border="0" cellpadding="10" cellspacing="10"><tr><td width="484"><strong>Виктор Судаков "Как говорит Бог?"</strong><p><iframe allowfullscreen="" frameborder="0" scrolling="no" height="298"  width="480" src="https://www.youtube.com/embed/yEQlNeuoN9k"></iframe></p></td></tr></table><table style="display: inline" border="0"><tr><td width="28"></td></tr></table>




<table style="display: inline" border="0"><tr><td width="28"></td></tr></table><table style="display: inline" border="0" cellpadding="10" cellspacing="10"><tr><td width="484"><strong>Последний крик петуха</strong><p><iframe allowfullscreen="" frameborder="0" scrolling="no" height="298"  width="480" src="https://www.youtube.com/embed/gJxaLErI_p8"></iframe></p></td></tr></table><table style="display: inline" border="0"><tr><td width="28"></td></tr></table>




<table style="display: inline" border="0"><tr><td width="28"></td></tr></table><table style="display: inline" border="0" cellpadding="10" cellspacing="10"><tr><td width="484"><strong>Три урока от семечка</strong><p><iframe allowfullscreen="" frameborder="0" scrolling="no" height="298"  width="480" src="https://www.youtube.com/embed/idAHW3AFRjU"></iframe></p></td></tr></table><table style="display: inline" border="0"><tr><td width="28"></td></tr></table>




<table style="display: inline" border="0"><tr><td width="28"></td></tr></table><table style="display: inline" border="0" cellpadding="10" cellspacing="10"><tr><td width="484"><strong>Жизнь во сне (часть 2)</strong><p><iframe allowfullscreen="" frameborder="0" scrolling="no" height="298"  width="480" src="https://www.youtube.com/embed/l_QRgbDDK2o"></iframe></p></td></tr></table><table style="display: inline" border="0"><tr><td width="28"></td></tr></table>




<table style="display: inline" border="0"><tr><td width="28"></td></tr></table><table style="display: inline" border="0" cellpadding="10" cellspacing="10"><tr><td width="484"><strong>Сложный выбор</strong><p><iframe allowfullscreen="" frameborder="0" scrolling="no" height="298"  width="480" src="https://www.youtube.com/embed/esFElRy-4-U"></iframe></p></td></tr></table><table style="display: inline" border="0"><tr><td width="28"></td></tr></table>




<table style="display: inline" border="0"><tr><td width="28"></td></tr></table><table style="display: inline" border="0" cellpadding="10" cellspacing="10"><tr><td width="484"><strong>Трагедия Самсона</strong><p><iframe allowfullscreen="" frameborder="0" scrolling="no" height="298"  width="480" src="https://www.youtube.com/embed/Eg81gfFVANk"></iframe></p></td></tr></table><table style="display: inline" border="0"><tr><td width="28"></td></tr></table>




<table style="display: inline" border="0"><tr><td width="28"></td></tr></table><table style="display: inline" border="0" cellpadding="10" cellspacing="10"><tr><td width="484"><strong>О настоящей любви</strong><p><iframe allowfullscreen="" frameborder="0" scrolling="no" height="298"  width="480" src="https://www.youtube.com/embed/6NAmU2907xI"></iframe></p></td></tr></table><table style="display: inline" border="0"><tr><td width="28"></td></tr></table>




<table style="display: inline" border="0"><tr><td width="28"></td></tr></table><table style="display: inline" border="0" cellpadding="10" cellspacing="10"><tr><td width="484"><strong>Явление силы и духа</strong><p><iframe allowfullscreen="" frameborder="0" scrolling="no" height="298"  width="480" src="https://www.youtube.com/embed/HMr6xSALEqM"></iframe></p></td></tr></table><table style="display: inline" border="0"><tr><td width="28"></td></tr></table>




<table style="display: inline" border="0"><tr><td width="28"></td></tr></table><table style="display: inline" border="0" cellpadding="10" cellspacing="10"><tr><td width="484"><strong>Взойти на гору Преображения </strong><p><iframe allowfullscreen="" frameborder="0" scrolling="no" height="298"  width="480" src="https://www.youtube.com/embed/yuyuz3eYGqs"></iframe></p></td></tr></table><table style="display: inline" border="0"><tr><td width="28"></td></tr></table>




<table style="display: inline" border="0"><tr><td width="28"></td></tr></table><table style="display: inline" border="0" cellpadding="10" cellspacing="10"><tr><td width="484"><strong>Внутреннее и внешнее</strong><p><iframe allowfullscreen="" frameborder="0" scrolling="no" height="298"  width="480" src="https://www.youtube.com/embed/6i-QyVq5i-o"></iframe></p></td></tr></table><table style="display: inline" border="0"><tr><td width="28"></td></tr></table>





<table style="display: inline" border="0"><tr><td width="28"></td></tr></table><table style="display: inline" border="0" cellpadding="10" cellspacing="10"><tr><td width="484"><strong>Виктор Судаков - Худая молва</strong><p><iframe allowfullscreen="" frameborder="0" scrolling="no" height="298"  width="480" src="https://www.youtube.com/embed/t9MayAVPya8"></iframe></p></td></tr></table><table style="display: inline" border="0"><tr><td width="28"></td></tr></table>




<table style="display: inline" border="0"><tr><td width="28"></td></tr></table><table style="display: inline" border="0" cellpadding="10" cellspacing="10"><tr><td width="484"><strong>Соучастие и тоска</strong><p><iframe allowfullscreen="" frameborder="0" scrolling="no" height="298"  width="480" src="https://www.youtube.com/embed/iO2IvJDs_6M"></iframe></p></td></tr></table><table style="display: inline" border="0"><tr><td width="28"></td></tr></table>




<table style="display: inline" border="0"><tr><td width="28"></td></tr></table><table style="display: inline" border="0" cellpadding="10" cellspacing="10"><tr><td width="484"><strong>Как выйти из депрессии?</strong><p><iframe allowfullscreen="" frameborder="0" scrolling="no" height="298"  width="480" src="https://www.youtube.com/embed/enul4PI22Uw"></iframe></p></td></tr></table><table style="display: inline" border="0"><tr><td width="28"></td></tr></table>













<table style="display: inline" border="0"><tr><td width="28"></td></tr></table><table style="display: inline" border="0" cellpadding="10" cellspacing="10"><tr><td width="484"><strong>Божье призвание</strong><p><iframe allowfullscreen="" frameborder="0" scrolling="no" height="298"  width="480" src="https://www.youtube.com/embed/Xl5vm5rbb40"></iframe></p></td></tr></table><table style="display: inline" border="0"><tr><td width="28"></td></tr></table>





<table style="display: inline" border="0"><tr><td width="28"></td></tr></table><table style="display: inline" border="0" cellpadding="10" cellspacing="10"><tr><td width="484"><strong>Авиакатастрофы в Екатеринбурге</strong><p><iframe allowfullscreen="" frameborder="0" scrolling="no" height="298"  width="480" src="https://www.youtube.com/embed/IWPxWaGmWGk"></iframe></p></td></tr></table><table style="display: inline" border="0"><tr><td width="28"></td></tr></table>





<table style="display: inline" border="0"><tr><td width="28"></td></tr></table><table style="display: inline" border="0" cellpadding="10" cellspacing="10"><tr><td width="484"><strong>Благословение или благоволение?</strong><p><iframe allowfullscreen="" frameborder="0" scrolling="no" height="298"  width="480" src="https://www.youtube.com/embed/Ft4e5fT62Nc"></iframe></p></td></tr></table><table style="display: inline" border="0"><tr><td width="28"></td></tr></table>





<table style="display: inline" border="0"><tr><td width="28"></td></tr></table><table style="display: inline" border="0" cellpadding="10" cellspacing="10"><tr><td width="484"><strong>Пустая бравада, или дорога в ад начинается с первого шага</strong><p><iframe allowfullscreen="" frameborder="0" scrolling="no" height="298"  width="480" src="https://www.youtube.com/embed/MwNU-lm5Ncg"></iframe></p></td></tr></table><table style="display: inline" border="0"><tr><td width="28"></td></tr></table>





<table style="display: inline" border="0"><tr><td width="28"></td></tr></table><table style="display: inline" border="0" cellpadding="10" cellspacing="10"><tr><td width="484"><strong>Как избежать кумиров?</strong><p><iframe allowfullscreen="" frameborder="0" scrolling="no" height="298"  width="480" src="https://www.youtube.com/embed/2ytFBw7GIs4"></iframe></p></td></tr></table><table style="display: inline" border="0"><tr><td width="28"></td></tr></table>





<table style="display: inline" border="0"><tr><td width="28"></td></tr></table><table style="display: inline" border="0" cellpadding="10" cellspacing="10"><tr><td width="484"><strong>Праздник Реформации - концертная программа</strong><p><iframe allowfullscreen="" frameborder="0" scrolling="no" height="298"  width="480" src="https://www.youtube.com/embed/T6bGJV4q-fo"></iframe></p></td></tr></table><table style="display: inline" border="0"><tr><td width="28"></td></tr></table>





<table style="display: inline" border="0"><tr><td width="28"></td></tr></table><table style="display: inline" border="0" cellpadding="10" cellspacing="10"><tr><td width="484"><strong>Праздник Реформации - проповедь</strong><p><iframe allowfullscreen="" frameborder="0" scrolling="no" height="298"  width="480" src="https://www.youtube.com/embed/11InBTZ8j8Y"></iframe></p></td></tr></table><table style="display: inline" border="0"><tr><td width="28"></td></tr></table>





<table style="display: inline" border="0"><tr><td width="28"></td></tr></table><table style="display: inline" border="0" cellpadding="10" cellspacing="10"><tr><td width="484"><strong>Павел Райн - У Господа есть лучший сценарий для твоей жизни</strong><p><iframe allowfullscreen="" frameborder="0" scrolling="no" height="298"  width="480" src="https://www.youtube.com/embed/5ZARusK1cos"></iframe></p></td></tr></table><table style="display: inline" border="0"><tr><td width="28"></td></tr></table>





<table style="display: inline" border="0"><tr><td width="28"></td></tr></table><table style="display: inline" border="0" cellpadding="10" cellspacing="10"><tr><td width="484"><strong>Николай Судаков - Истинное посвящение Богу</strong><p><iframe allowfullscreen="" frameborder="0" scrolling="no" height="298"  width="480" src="https://www.youtube.com/embed/IaB_gKKTtIs"></iframe></p></td></tr></table><table style="display: inline" border="0"><tr><td width="28"></td></tr></table>





<table style="display: inline" border="0"><tr><td width="28"></td></tr></table><table style="display: inline" border="0" cellpadding="10" cellspacing="10"><tr><td width="484"><strong>Диана Судакова - 6-ая женская конференция </strong><p><iframe allowfullscreen="" frameborder="0" scrolling="no" height="298"  width="480" src="https://www.youtube.com/embed/--qc_07aTLs"></iframe></p></td></tr></table><table style="display: inline" border="0"><tr><td width="28"></td></tr></table>





<table style="display: inline" border="0"><tr><td width="28"></td></tr></table><table style="display: inline" border="0" cellpadding="10" cellspacing="10"><tr><td width="484"><strong>Виктор Судаков - О патриотизме</strong><p><iframe allowfullscreen="" frameborder="0" scrolling="no" height="298"  width="480" src="https://www.youtube.com/embed/QGel_0xJfQo"></iframe></p></td></tr></table><table style="display: inline" border="0"><tr><td width="28"></td></tr></table>





<table style="display: inline" border="0"><tr><td width="28"></td></tr></table><table style="display: inline" border="0" cellpadding="10" cellspacing="10"><tr><td width="484"><strong>Виктор Судаков - Ян Гус: вера, неподвластная огню!</strong><p><iframe allowfullscreen="" frameborder="0" scrolling="no" height="298"  width="480" src="https://www.youtube.com/embed/9mk6uV0coMg"></iframe></p></td></tr></table><table style="display: inline" border="0"><tr><td width="28"></td></tr></table>





<table style="display: inline" border="0"><tr><td width="28"></td></tr></table><table style="display: inline" border="0" cellpadding="10" cellspacing="10"><tr><td width="484"><strong>Виктор Судаков - Верблюд и игольные уши</strong><p><iframe allowfullscreen="" frameborder="0" scrolling="no" height="298"  width="480" src="https://www.youtube.com/embed/ARa2cW5WGtk"></iframe></p></td></tr></table><table style="display: inline" border="0"><tr><td width="28"></td></tr></table>





<table style="display: inline" border="0"><tr><td width="28"></td></tr></table><table style="display: inline" border="0" cellpadding="10" cellspacing="10"><tr><td width="484"><strong>Виктор Судаков - О честности</strong><p><iframe allowfullscreen="" frameborder="0" scrolling="no" height="298"  width="480" src="https://www.youtube.com/embed/o7nhWoYdPdw"></iframe></p></td></tr></table><table style="display: inline" border="0"><tr><td width="28"></td></tr></table>





<table style="display: inline" border="0"><tr><td width="28"></td></tr></table><table style="display: inline" border="0" cellpadding="10" cellspacing="10"><tr><td width="484"><strong>Виктор Судаков - Четыре картины жизни</strong><p><iframe allowfullscreen="" frameborder="0" scrolling="no" height="298"  width="480" src="https://www.youtube.com/embed/dKeo1LmdShA"></iframe></p></td></tr></table><table style="display: inline" border="0"><tr><td width="28"></td></tr></table>





<table style="display: inline" border="0"><tr><td width="28"></td></tr></table><table style="display: inline" border="0" cellpadding="10" cellspacing="10"><tr><td width="484"><strong>Виктор Судаков - О крещении Духом Святым</strong><p><iframe allowfullscreen="" frameborder="0" scrolling="no" height="298"  width="480" src="https://www.youtube.com/embed/l-7Xs1njYjw"></iframe></p></td></tr></table><table style="display: inline" border="0"><tr><td width="28"></td></tr></table>




