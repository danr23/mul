<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<div align="center">
<table border="0" width="94%">
<tr>
<td>
<h3 align="center">
<font face="verdana" color="#333333">
<img border="0" align="left" hspace="9" vspace="9" src="http://newlife.ru/img/imgo.png" width="110">
<br>
Ближайшие мероприятия церкви "НОВАЯ ЖИЗНЬ":
</font>
</h3>
<br>
<hr color="#232323" width="50%">
<br>
<?php
error_reporting(0);

$linksimgs = array(
   
            'http://newlife.ru/page.php?page=obshecerkovnye-slugheniya' => 'http://newlife.ru/adminpanel/imgemaileventsn/obshsl.jpg',   'http://newlife.ru/page.php?page=ihop' => 'http://newlife.ru/adminpanel/imgemaileventsn/ihop.jpg',   'http://newlife.ru/page.php?page=sozercanie' => 'http://newlife.ru/adminpanel/imgemaileventsn/sozercanie.jpg',
  
            'http://newlife.ru/page.php?page=ghenskoeslughenie' => 'http://newlife.ru/adminpanel/imgemaileventsn/mudrostmatery.jpg',   'http://newlife.ru/page.php?page=youth' => 'http://newlife.ru/adminpanel/imgemaileventsn/youth.jpg',   'http://newlife.ru/page.php?page=domgr' => 'http://newlife.ru/adminpanel/imgemaileventsn/domgr.jpg',

	    'http://newlife.ru/page.php?page=hodataystvo' => 'http://newlife.ru/adminpanel/imgemaileventsn/hodataystvo.jpg',   'http://newlife.ru/page.php?page=httpnewliferumolitvavt' => 'http://newlife.ru/adminpanel/imgemaileventsn/social.jpg',
  
        ); 

$Sun='Sun';
$dennedeli=DATE("D");
if ($dennedeli==$Sun) {













$jsonString = file_get_contents("http://newlife.ru/adminpanel/jsontos.php"); 
$cart = json_decode( $jsonString );
$timemoment = time();
$tmms = $timemoment*1000;
$tmmsplus = $tmms+64800000;
$today = date( 'j.n.Y', "$timemoment" );
print '
<p align="center">
<font face="verdana" size="5" color="#cc0000">
<strong>
Сегодня
</strong>
</font>
 
<font face="verdana" size="5" color="#cc0000">
(' ;
echo "$today";
print '):
</font>
</p>
';

    foreach($cart as $item){
if ("$item->date" > "$tmms" && "$item->date" < "$tmmsplus") {

$dth = "$item->date";
$dth = $dth/1000;
//echo "$dth<br><br>";
$dh = date( 'j.n.Y', "$dth" );
$th = date( 'H:i', "$dth" );
echo '
<p align="left">
<font face="Verdana" color="#389e95">
<strong>
';
echo "$th";
echo '
</strong>
</font>
 
<font face="Verdana" color="#000000">
(';
echo "$dh";
echo ')
</font>
</p>
<p align="left">
<font face="Verdana" color="#222222">
<strong>
';
echo "$item->title";
echo '
</strong>
</font>
</p>
<p align="left">
<font face="Verdana" color="#222222">
<em>
';
echo "$item->description";
echo '
</em>
</font>
</p>
';
if ($item->url == '') {
} else {
echo '
<p>
<a target="_blank" href="';
echo "$item->url";
echo '">
<img border="0" width="650" alt="" src="';
if (array_key_exists($item->url, $linksimgs)) {
$urlimg = strtr($item->url, $linksimgs);
} else {
$urlimg = 'http://newlife.ru/adminpanel/imgemaileventsn/podrobnee(0IMG).jpg';
}
echo "$urlimg";
echo '">
</a>
</p>
';
}
echo '
<p>
<br>
</p>
';
} else {
}

    }

echo '<br><hr color="#232323" width="80%"><br>';

error_reporting(0);
$jsonString = file_get_contents("http://newlife.ru/adminpanel/jsontos.php"); 
$cart = json_decode( $jsonString );
$timemoment = time();
$tmms = $timemoment*1000;
$tmmsplus = $tmms+64800000;
$tmmsplusplus = $tmmsplus+86400000;
$timemomzavtra = $timemoment+86400;
$zavtra = date( 'j.n.Y', "$timemomzavtra" );
print '
<p align="center">
<font face="verdana" size="5" color="#cc0000">
<strong>
Понедельник
</strong>
</font>
 
<font face="verdana" size="5" color="#cc0000">
(' ;
echo "$zavtra";
print '):
</font>
</p>
';
    foreach($cart as $item){
if ("$item->date" > "$tmmsplus" && "$item->date" < "$tmmsplusplus") {

$dth = "$item->date";
$dth = $dth/1000;
//echo "$dth<br><br>";
$dh = date( 'j.n.Y', "$dth" );
$th = date( 'H:i', "$dth" );
echo '
<p align="left">
<font face="Verdana" color="#389e95">
<strong>
';
echo "$th";
echo '
</strong>
</font>
 
<font face="Verdana" color="#000000">
(';
echo "$dh";
echo ')
</font>
</p>
<p align="left">
<font face="Verdana" color="#222222">
<strong>
';
echo "$item->title";
echo '
</strong>
</font>
</p>
<p align="left">
<font face="Verdana" color="#222222">
<em>
';
echo "$item->description";
echo '
</em>
</font>
</p>
';
if ($item->url == '') {
} else {
echo '
<p>
<a target="_blank" href="';
echo "$item->url";
echo '">
<img border="0" width="650" alt="" src="';
if (array_key_exists($item->url, $linksimgs)) {
$urlimg = strtr($item->url, $linksimgs);
} else {
$urlimg = 'http://newlife.ru/adminpanel/imgemaileventsn/podrobnee(0IMG).jpg';
}
echo "$urlimg";
echo '">
</a>
</p>
';
}
echo '
<p>
<br>
</p>
';
} else {
}

    }







error_reporting(0);
$jsonString = file_get_contents("http://newlife.ru/adminpanel/jsontos.php"); 
$cart = json_decode( $jsonString );
$timemoment = time();
$tmms = $timemoment*1000;
$tmmsplus = $tmms+86400000;
$tmmsplusplus = $tmmsplus+86400000;
$timemomzavtra = $timemoment+172800;
$zavtra = date( 'j.n.Y', "$timemomzavtra" );
print '
<p align="center">
<font face="verdana" size="5" color="#cc0000">
<strong>
Вторник
</strong>
</font>
 
<font face="verdana" size="5" color="#cc0000">
(' ;
echo "$zavtra";
print '):
</font>
</p>
';
    foreach($cart as $item){
if ("$item->date" > "$tmmsplus" && "$item->date" < "$tmmsplusplus") {

$dth = "$item->date";
$dth = $dth/1000;
//echo "$dth<br><br>";
$dh = date( 'j.n.Y', "$dth" );
$th = date( 'H:i', "$dth" );
echo '
<p align="left">
<font face="Verdana" color="#389e95">
<strong>
';
echo "$th";
echo '
</strong>
</font>
 
<font face="Verdana" color="#000000">
(';
echo "$dh";
echo ')
</font>
</p>
<p align="left">
<font face="Verdana" color="#222222">
<strong>
';
echo "$item->title";
echo '
</strong>
</font>
</p>
<p align="left">
<font face="Verdana" color="#222222">
<em>
';
echo "$item->description";
echo '
</em>
</font>
</p>
';
if ($item->url == '') {
} else {
echo '
<p>
<a target="_blank" href="';
echo "$item->url";
echo '">
<img border="0" width="650" alt="" src="';
if (array_key_exists($item->url, $linksimgs)) {
$urlimg = strtr($item->url, $linksimgs);
} else {
$urlimg = 'http://newlife.ru/adminpanel/imgemaileventsn/podrobnee(0IMG).jpg';
}
echo "$urlimg";
echo '">
</a>
</p>
';
}
echo '
<p>
<br>
</p>
';
} else {
}

    }


error_reporting(0);
$jsonString = file_get_contents("http://newlife.ru/adminpanel/jsontos.php"); 
$cart = json_decode( $jsonString );
$timemoment = time();
$tmms = $timemoment*1000;
$tmmsplus = $tmms+172800000;
$tmmsplusplus = $tmmsplus+86400000;
$timemomzavtra = $timemoment+259200;
$zavtra = date( 'j.n.Y', "$timemomzavtra" );
print '
<p align="center">
<font face="verdana" size="5" color="#cc0000">
<strong>
Среда
</strong>
</font>
 
<font face="verdana" size="5" color="#cc0000">
(' ;
echo "$zavtra";
print '):
</font>
</p>
';
    foreach($cart as $item){
if ("$item->date" > "$tmmsplus" && "$item->date" < "$tmmsplusplus") {

$dth = "$item->date";
$dth = $dth/1000;
//echo "$dth<br><br>";
$dh = date( 'j.n.Y', "$dth" );
$th = date( 'H:i', "$dth" );
echo '
<p align="left">
<font face="Verdana" color="#389e95">
<strong>
';
echo "$th";
echo '
</strong>
</font>
 
<font face="Verdana" color="#000000">
(';
echo "$dh";
echo ')
</font>
</p>
<p align="left">
<font face="Verdana" color="#222222">
<strong>
';
echo "$item->title";
echo '
</strong>
</font>
</p>
<p align="left">
<font face="Verdana" color="#222222">
<em>
';
echo "$item->description";
echo '
</em>
</font>
</p>
';
if ($item->url == '') {
} else {
echo '
<p>
<a target="_blank" href="';
echo "$item->url";
echo '">
<img border="0" width="650" alt="" src="';
if (array_key_exists($item->url, $linksimgs)) {
$urlimg = strtr($item->url, $linksimgs);
} else {
$urlimg = 'http://newlife.ru/adminpanel/imgemaileventsn/podrobnee(0IMG).jpg';
}
echo "$urlimg";
echo '">
</a>
</p>
';
}
echo '
<p>
<br>
</p>
';
} else {
}

    }


error_reporting(0);
$jsonString = file_get_contents("http://newlife.ru/adminpanel/jsontos.php"); 
$cart = json_decode( $jsonString );
$timemoment = time();
$tmms = $timemoment*1000;
$tmmsplus = $tmms+259200000;
$tmmsplusplus = $tmmsplus+86400000;
$timemomzavtra = $timemoment+345600;
$zavtra = date( 'j.n.Y', "$timemomzavtra" );
print '
<p align="center">
<font face="verdana" size="5" color="#cc0000">
<strong>
Четверг
</strong>
</font>
 
<font face="verdana" size="5" color="#cc0000">
(' ;
echo "$zavtra";
print '):
</font>
</p>
';
    foreach($cart as $item){
if ("$item->date" > "$tmmsplus" && "$item->date" < "$tmmsplusplus") {

$dth = "$item->date";
$dth = $dth/1000;
//echo "$dth<br><br>";
$dh = date( 'j.n.Y', "$dth" );
$th = date( 'H:i', "$dth" );
echo '
<p align="left">
<font face="Verdana" color="#389e95">
<strong>
';
echo "$th";
echo '
</strong>
</font>
 
<font face="Verdana" color="#000000">
(';
echo "$dh";
echo ')
</font>
</p>
<p align="left">
<font face="Verdana" color="#222222">
<strong>
';
echo "$item->title";
echo '
</strong>
</font>
</p>
<p align="left">
<font face="Verdana" color="#222222">
<em>
';
echo "$item->description";
echo '
</em>
</font>
</p>
';
if ($item->url == '') {
} else {
echo '
<p>
<a target="_blank" href="';
echo "$item->url";
echo '">
<img border="0" width="650" alt="" src="';
if (array_key_exists($item->url, $linksimgs)) {
$urlimg = strtr($item->url, $linksimgs);
} else {
$urlimg = 'http://newlife.ru/adminpanel/imgemaileventsn/podrobnee(0IMG).jpg';
}
echo "$urlimg";
echo '">
</a>
</p>
';
}
echo '
<p>
<br>
</p>
';
} else {
}

    }


error_reporting(0);
$jsonString = file_get_contents("http://newlife.ru/adminpanel/jsontos.php"); 
$cart = json_decode( $jsonString );
$timemoment = time();
$tmms = $timemoment*1000;
$tmmsplus = $tmms+345600000;
$tmmsplusplus = $tmmsplus+86400000;
$timemomzavtra = $timemoment+432000;
$zavtra = date( 'j.n.Y', "$timemomzavtra" );
print '
<p align="center">
<font face="verdana" size="5" color="#cc0000">
<strong>
Пятница
</strong>
</font>
 
<font face="verdana" size="5" color="#cc0000">
(' ;
echo "$zavtra";
print '):
</font>
</p>
';
    foreach($cart as $item){
if ("$item->date" > "$tmmsplus" && "$item->date" < "$tmmsplusplus") {

$dth = "$item->date";
$dth = $dth/1000;
//echo "$dth<br><br>";
$dh = date( 'j.n.Y', "$dth" );
$th = date( 'H:i', "$dth" );
echo '
<p align="left">
<font face="Verdana" color="#389e95">
<strong>
';
echo "$th";
echo '
</strong>
</font>
 
<font face="Verdana" color="#000000">
(';
echo "$dh";
echo ')
</font>
</p>
<p align="left">
<font face="Verdana" color="#222222">
<strong>
';
echo "$item->title";
echo '
</strong>
</font>
</p>
<p align="left">
<font face="Verdana" color="#222222">
<em>
';
echo "$item->description";
echo '
</em>
</font>
</p>
';
if ($item->url == '') {
} else {
echo '
<p>
<a target="_blank" href="';
echo "$item->url";
echo '">
<img border="0" width="650" alt="" src="';
if (array_key_exists($item->url, $linksimgs)) {
$urlimg = strtr($item->url, $linksimgs);
} else {
$urlimg = 'http://newlife.ru/adminpanel/imgemaileventsn/podrobnee(0IMG).jpg';
}
echo "$urlimg";
echo '">
</a>
</p>
';
}
echo '
<p>
<br>
</p>
';
} else {
}

    }


error_reporting(0);
$jsonString = file_get_contents("http://newlife.ru/adminpanel/jsontos.php"); 
$cart = json_decode( $jsonString );
$timemoment = time();
$tmms = $timemoment*1000;
$tmmsplus = $tmms+432000000;
$tmmsplusplus = $tmmsplus+86400000;
$timemomzavtra = $timemoment+518400;
$zavtra = date( 'j.n.Y', "$timemomzavtra" );
print '
<p align="center">
<font face="verdana" size="5" color="#cc0000">
<strong>
Суббота
</strong>
</font>
 
<font face="verdana" size="5" color="#cc0000">
(' ;
echo "$zavtra";
print '):
</font>
</p>
';
    foreach($cart as $item){
if ("$item->date" > "$tmmsplus" && "$item->date" < "$tmmsplusplus") {

$dth = "$item->date";
$dth = $dth/1000;
//echo "$dth<br><br>";
$dh = date( 'j.n.Y', "$dth" );
$th = date( 'H:i', "$dth" );
echo '
<p align="left">
<font face="Verdana" color="#389e95">
<strong>
';
echo "$th";
echo '
</strong>
</font>
 
<font face="Verdana" color="#000000">
(';
echo "$dh";
echo ')
</font>
</p>
<p align="left">
<font face="Verdana" color="#222222">
<strong>
';
echo "$item->title";
echo '
</strong>
</font>
</p>
<p align="left">
<font face="Verdana" color="#222222">
<em>
';
echo "$item->description";
echo '
</em>
</font>
</p>
';
if ($item->url == '') {
} else {
echo '
<p>
<a target="_blank" href="';
echo "$item->url";
echo '">
<img border="0" width="650" alt="" src="';
if (array_key_exists($item->url, $linksimgs)) {
$urlimg = strtr($item->url, $linksimgs);
} else {
$urlimg = 'http://newlife.ru/adminpanel/imgemaileventsn/podrobnee(0IMG).jpg';
}
echo "$urlimg";
echo '">
</a>
</p>
';
}
echo '
<p>
<br>
</p>
';
} else {
}

    }


error_reporting(0);
$jsonString = file_get_contents("http://newlife.ru/adminpanel/jsontos.php"); 
$cart = json_decode( $jsonString );
$timemoment = time();
$tmms = $timemoment*1000;
$tmmsplus = $tmms+518400000;
$tmmsplusplus = $tmmsplus+86400000;
$timemomzavtra = $timemoment+604800;
$zavtra = date( 'j.n.Y', "$timemomzavtra" );
print '
<p align="center">
<font face="verdana" size="5" color="#cc0000">
<strong>
Воскресенье
</strong>
</font>
 
<font face="verdana" size="5" color="#cc0000">
(' ;
echo "$zavtra";
print '):
</font>
</p>
';
    foreach($cart as $item){
if ("$item->date" > "$tmmsplus" && "$item->date" < "$tmmsplusplus") {

$dth = "$item->date";
$dth = $dth/1000;
//echo "$dth<br><br>";
$dh = date( 'j.n.Y', "$dth" );
$th = date( 'H:i', "$dth" );
echo '
<p align="left">
<font face="Verdana" color="#389e95">
<strong>
';
echo "$th";
echo '
</strong>
</font>
 
<font face="Verdana" color="#000000">
(';
echo "$dh";
echo ')
</font>
</p>
<p align="left">
<font face="Verdana" color="#222222">
<strong>
';
echo "$item->title";
echo '
</strong>
</font>
</p>
<p align="left">
<font face="Verdana" color="#222222">
<em>
';
echo "$item->description";
echo '
</em>
</font>
</p>
';
if ($item->url == '') {
} else {
echo '
<p>
<a target="_blank" href="';
echo "$item->url";
echo '">
<img border="0" width="650" alt="" src="';
if (array_key_exists($item->url, $linksimgs)) {
$urlimg = strtr($item->url, $linksimgs);
} else {
$urlimg = 'http://newlife.ru/adminpanel/imgemaileventsn/podrobnee(0IMG).jpg';
}
echo "$urlimg";
echo '">
</a>
</p>
';
}
echo '
<p>
<br>
</p>
';
} else {
}

    }











}
else
{




$jsonString = file_get_contents("http://newlife.ru/adminpanel/jsontos.php"); 
$cart = json_decode( $jsonString );
$timemoment = time();
$tmms = $timemoment*1000;
$tmmsplus = $tmms+64800000;
$today = date( 'j.n.Y', "$timemoment" );
print '
<p align="center">
<font face="verdana" size="5" color="#cc0000">
<strong>
Сегодня
</strong>
</font>
 
<font face="verdana" size="5" color="#cc0000">
(' ;
echo "$today";
print '):
</font>
</p>
';

    foreach($cart as $item){
if ("$item->date" > "$tmms" && "$item->date" < "$tmmsplus") {

$dth = "$item->date";
$dth = $dth/1000;
//echo "$dth<br><br>";
$dh = date( 'j.n.Y', "$dth" );
$th = date( 'H:i', "$dth" );
echo '
<p align="left">
<font face="Verdana" color="#389e95">
<strong>
';
echo "$th";
echo '
</strong>
</font>
 
<font face="Verdana" color="#000000">
(';
echo "$dh";
echo ')
</font>
</p>
<p align="left">
<font face="Verdana" color="#222222">
<strong>
';
echo "$item->title";
echo '
</strong>
</font>
</p>
<p align="left">
<font face="Verdana" color="#222222">
<em>
';
echo "$item->description";
echo '
</em>
</font>
</p>
';
if ($item->url == '') {
} else {
echo '
<p>
<a target="_blank" href="';
echo "$item->url";
echo '">
<img border="0" width="650" alt="" src="';
if (array_key_exists($item->url, $linksimgs)) {
$urlimg = strtr($item->url, $linksimgs);
} else {
$urlimg = 'http://newlife.ru/adminpanel/imgemaileventsn/podrobnee(0IMG).jpg';
}
echo "$urlimg";
echo '">
</a>
</p>
';
}
echo '
<p>
<br>
</p>
';
} else {
}

    }


echo '<br><hr color="#232323" width="80%"><br>';

error_reporting(0);
$jsonString = file_get_contents("http://newlife.ru/adminpanel/jsontos.php"); 
$cart = json_decode( $jsonString );
$timemoment = time();
$tmms = $timemoment*1000;
$tmmsplus = $tmms+64800000;
$tmmsplusplus = $tmmsplus+86400000;
$timemomzavtra = $timemoment+86400;
$zavtra = date( 'j.n.Y', "$timemomzavtra" );
print '
<p align="center">
<font face="verdana" size="5" color="#cc0000">
<strong>
Завтра
</strong>
</font>
 
<font face="verdana" size="5" color="#cc0000">
(' ;
echo "$zavtra";
print '):
</font>
</p>
';
    foreach($cart as $item){
if ("$item->date" > "$tmmsplus" && "$item->date" < "$tmmsplusplus") {

$dth = "$item->date";
$dth = $dth/1000;
//echo "$dth<br><br>";
$dh = date( 'j.n.Y', "$dth" );
$th = date( 'H:i', "$dth" );
echo '
<p align="left">
<font face="Verdana" color="#389e95">
<strong>
';
echo "$th";
echo '
</strong>
</font>
 
<font face="Verdana" color="#000000">
(';
echo "$dh";
echo ')
</font>
</p>
<p align="left">
<font face="Verdana" color="#222222">
<strong>
';
echo "$item->title";
echo '
</strong>
</font>
</p>
<p align="left">
<font face="Verdana" color="#222222">
<em>
';
echo "$item->description";
echo '
</em>
</font>
</p>
';
if ($item->url == '') {
} else {
echo '
<p>
<a target="_blank" href="';
echo "$item->url";
echo '">
<img border="0" width="650" alt="" src="';
if (array_key_exists($item->url, $linksimgs)) {
$urlimg = strtr($item->url, $linksimgs);
} else {
$urlimg = 'http://newlife.ru/adminpanel/imgemaileventsn/podrobnee(0IMG).jpg';
}
echo "$urlimg";
echo '">
</a>
</p>
';
}
echo '
<p>
<br>
</p>
';
} else {
}

    }



}

?>





<br>
<p align="center">
<font face="verdana" color="#333333">
<em>
подробнее на сайте 
<a href="http://newlife.ru" target="_blank">
<font face="Verdana" color="#1e544f">
newlife.ru
</font>
</a>
</em>
</font>
</p>
<br>

</td>
</tr>
</table>
</div>

