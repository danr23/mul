<?php
 $lines = array_reverse(file('Data.php'));

// Осуществим проход массива и выведем номера строк и их содержимое в виде HTML-кода.
foreach ($lines as $line_num => $line) {
    echo $line;
    

} 
?>
