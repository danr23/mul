<html xml:lang="ru-ru" lang="ru-ru">
<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
</head>
<body>
<div align="center">
<table border="0" align="center" width="1190" border="0" cellpadding="3" cellspacing="3"><tr><td><div align="justify">
<?php
include 'Datamp.php';
?>
</div></td></tr></table>
</div>
</body>
</html>
