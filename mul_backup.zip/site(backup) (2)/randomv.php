<?php
function GetListFiles($folder,&$all_files){
	$fp=opendir($folder);
	while($cv_file=readdir($fp)){
		if(is_file($folder."/".$cv_file)){
			$all_files[]=$folder."/".$cv_file;
		}
		elseif($cv_file!="."&&$cv_file!=".."&&is_dir($folder."/".$cv_file)){
			GetListFiles($folder."/".$cv_file,$all_files);
		}
	}
	closedir($fp);
}
$all_files=array();
GetListFiles('uploads/',$all_files);
//print_r($all_files);




 srand ((double) microtime() * 1000000);
    $random_number = rand(0,count($all_files)-1);
    echo '<div><video align="left" width="400" height="300" controls="controls">
   <source src="';
 echo ($all_files[$random_number]);  
  echo '" type=\'video/mp4; codecs="avc1.42E01E, mp4a.40.2"\'> </video>';

 
 
?>
