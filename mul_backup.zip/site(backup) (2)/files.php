<?php include "top.php"; ?>

<?php
$razdel = $_GET['razdel'];

$derectory = "uploads/$razdel/";
$openderectory=opendir($derectory);
while ($fileindir = readdir($openderectory))
{
if (($fileindir!=".")&&($fileindir!=".."))
        {
                $perem[] = $fileindir;
        }
}
closedir($openderectory);
if (sizeof($perem)!=0)
{
rsort($perem);
$all=sizeof($perem);

}
else
{
        echo ("NO");
        die;
}
    
    foreach($perem as $item){

    echo '<div><video align="left" width="400" height="300" controls="controls">
   <source src="';
    echo ($derectory.$item) ;
    echo '" type=\'video/mp4; codecs="avc1.42E01E, mp4a.40.2"\'> </video>';

    }

?>
<?php include "bottom.php"; ?>
