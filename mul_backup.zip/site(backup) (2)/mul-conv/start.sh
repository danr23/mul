#!/bin/bash
num=0;
cd "/home/$USER/mul-conv/in/";
for invideo in *;
do ffmpeg -i "$invideo" -vcodec libtheora -b 1000k -acodec libvorbis -ab 128k -ar 44100 -ac 2 "$invideo.f.ogg";
ffmpeg -i "$invideo.f.ogg" -an -ss 00:00:50 -r 1 -vframes 1 -y -f mjpeg "$invideo.jpg";
ffmpeg -i "$invideo.jpg" -vcodec libtheora -b 1000k -acodec libvorbis -ab 128k "$invideo.ogg";
ffmpeg -i /home/user/mul-conv/.m/1.mp3 -i "$invideo.ogg" -vcodec libtheora -b 1000k -acodec libvorbis -ab 128k -ar 44100 -ac 2 -strict -2 "$invideo.pa.ogg";
let "num += 1";
ffmpeg -i concat:"$invideo.pa.ogg|$invideo.f.ogg" -vcodec libtheora -b 1000k -acodec libvorbis -ab 128k -ar 44100 -ac 2 -strict -2 "/home/user/mul-conv/out/$num-OK.ogg";
done;
sleep 4;
find /home/$USER/mul-conv/in/* -delete;
