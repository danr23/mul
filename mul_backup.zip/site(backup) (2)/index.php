<?php include "top.php"; ?>
<p>
<?php include "randomvideo.php"; ?>
</p>
<p>
<?php include "answers-menu-base.htm"; ?>
</p>
<?php include "bottom.php"; ?>
