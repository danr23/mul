<html>
<head>
<title>site</title>
<script src="jquery.js"></script>
<script>
$(document).ready(function(){

        var $menu = $("#menu");

        $(window).scroll(function(){
            if ( $(this).scrollTop() > 100 && $menu.hasClass("default") ){
                $menu.removeClass("default").addClass("fixed");
            } else if($(this).scrollTop() <= 100 && $menu.hasClass("fixed")) {
                $menu.removeClass("fixed").addClass("default");
            }
        });//scroll
    });
    
    $(document).ready(function(){

        var $menu = $("#menu");

        $(window).scroll(function(){
            if ( $(this).scrollTop() > 100 && $menu.hasClass("default") ){
                $menu.fadeOut('fast',function(){
                    $(this).removeClass("default")
                           .addClass("fixed transbg")
                           .fadeIn('fast');
                });
            } else if($(this).scrollTop() <= 100 && $menu.hasClass("fixed")) {
                $menu.fadeOut('fast',function(){
                    $(this).removeClass("fixed transbg")
                           .addClass("default")
                           .fadeIn('fast');
                });
            }
        });//scroll

        $menu.hover(
            function(){
                if( $(this).hasClass('fixed') ){
                    $(this).removeClass('transbg');
                }
            },
            function(){
                if( $(this).hasClass('fixed') ){
                    $(this).addClass('transbg');
                }
            });//hover
    });//jQuery
</script>
<style>
#menu {
            text-transform: uppercase;
            text-align: center;
            line-height: 50px;
            background-color: rgba(240, 175, 175, 0.7)!important;

            text-shadow:0 1px 1px black;
           -moz-border-radius: 0px;
            -webkit-border-radius:0px;
            border-radius:0px;
        }
        #menu ul {
            padding:0;
            margin:0;
        }
        #menu li{
            display: inline;
            list-style:none;
            margin: 0px 0px;
        }

        #menu li a {
            padding:5px 10px;
            color:#fff;
            text-decoration: none;

            -webkit-border-radius: 5px;
            -moz-border-radius: 5px;
            border-radius: 5px;

        }

        #menu li a:hover{
            background: #eea;
            color: #ff0;

            -webkit-transition-property: color, background;
            -webkit-transition-duration: 0.5s, 0.5s;
        }
        .default {
            width:920px;
        }
        .fixed {
            position:fixed;
            bottom:-5px; left:0;
            width:100%;
            padding:0px 0;

            -moz-box-shadow: 0px 0px 50px #333;
            -webkit-box-shadow: 0px 0px 50px #333;
            box-shadow: 0px 0px 50px #333;
        }
        .transbg {
            background-color: rgba(240, 175, 175, 0.7)!important;
        }
#menu {
    width: 920px;
    text-transform: uppercase;
    text-align: center;
    line-height: 50px;
    background: #ffdcdc;
}
  #menu ul {
    padding:0;
    margin:0;
  }
  #menu li{
    display: inline;
    list-style:none;
    margin: 5px 10px;
  }
     #menu li a {
        padding:5px 10px;
        color:#fff;
        text-decoration: none;
     }
     #menu li a:hover{
        background: #eaa;
        color: #ff0;
     }
     #menu.default {
    width:100%;
}
#menu.fixed {
    position:fixed;
    bottom:0; left:0;
    width:100%;
    height:120px;
}
body {
position:block;
padding:0px;
margin:0px;
}
</style>

</head>
<body align="center">

<div id="menu" class="default">
        <ul>
            <a href="/user/site"><img border="0" src="mainphoto.png"></a>
            </ul>
    </div>

<div align="center">
<table width="1100" align="center" border="0"><tr align="center" border="0"><td align="center" border="0">
